# Hệ thống phân tích lợi nhuận dòng tiền và cổ tức tiền mặt

**Hướng người thực hiện đã chọn ngày 03/10/2026:**
**Xây dựng hệ thống thu thập và phân tích mối quan hệ giữa lợi nhuận, dòng tiền và cổ tức tiền mặt của doanh nghiệp niêm yết Việt Nam.**

Đây là hướng triển khai duy nhất. Năng lực phân tích BCTC có truy vết của A1 được tái sử dụng làm nền kỹ thuật cho ngách A2. Tên chính thức/rubric còn cần trao đổi với thầy; chưa có bằng chứng giảng viên đã phê duyệt.

## Phạm vi và quyết định chính

- Project: tự thu thập BCTC và thông báo cổ tức, trích/kiểm định/duyệt, ghép theo năm lợi nhuận, phân tích mô tả và ứng dụng truy nguồn.
- Đích dữ liệu cổ tức: **DPS tiền mặt được công bố**; ngày thanh toán theo lịch là trường riêng, xác nhận thực trả chỉ lưu khi có bằng chứng.
- Sáu trường BCTC lõi: LNST tổng, CFO, tiền và tương đương tiền, tổng tài sản, nợ phải trả, tổng VCSH. Doanh thu/EPS/phần LNST cổ đông mẹ/ngắn hạn là mở rộng có điều kiện.
- Pilot: 3 doanh nghiệp × 2023–2025 = 9 BCTC năm; chọn nguồn đủ rõ. Mục tiêu sau gate tuần 4: 5–8 doanh nghiệp, 15–24 BCTC năm. Cổ tức phải rà các đợt liên quan năm lợi nhuận, kể cả công bố ở năm khác.
- Ưu tiên doanh nghiệp phi tài chính; hợp nhất nếu có, cấp doanh nghiệp nếu thực sự không lập hợp nhất và đã xác nhận. Mỗi doanh nghiệp có series/scope riêng; không trộn scope trong tỷ số hoặc tương quan gộp.
- Một case cập nhật 2026 nếu đủ giờ; chưa cần mọi quý, giá thị trường, yield, TTM hoặc điểm bền vững tổng hợp.
- Dự đoán duy trì/giảm cổ tức là hướng tốt nghiệp. Project hiện tại không cần ML/RAG.

Ngân sách vẫn giả định 13 tuần, 10–12 giờ/tuần gồm học, làm, kiểm thử và Word/slide. Chưa gắn lịch học kỳ hoặc tự gửi báo cáo.

## Đọc theo thứ tự

1. [Quyết định chọn ngách](01-so-sanh-va-quyet-dinh.md).
2. [SRS và đóng góp IT](02-de-tai-va-srs.md).
3. [Phương pháp thu thập và xử lý](11-phuong-phap-thu-thap-va-xu-ly.md).
4. [Tài chính và từ điển](12-kien-thuc-tai-chinh-va-tu-dien.md).
5. [Kiến trúc và schema](03-kien-truc-va-du-lieu.md).
6. [Ghép sự kiện và phân tích](13-ghep-co-tuc-va-phan-tich.md).
7. [Kế hoạch học/làm](04-ke-hoach-13-tuan.md), [lộ trình học](05-lo-trinh-hoc.md).
8. [Đánh giá](06-danh-gia-va-nghiem-thu.md), [báo cáo tuần](07-bao-cao-hang-tuan.md).
9. [Bảo vệ](08-chuan-bi-bao-ve.md), [tốt nghiệp](09-lien-thong-tot-nghiep.md).
10. [Sổ nguồn](10-so-nguon.md), [backlog và quyết định](14-backlog-va-quyet-dinh.md).

[Word và slide hiện hành](reports/README.md) cùng phương pháp với bộ này.

## Bằng chứng đã có

Crawler mới tự phát hiện/tải 8 PDF năm 2025/bán niên 2026 của HPG, DHG, VHC, HPA; chạy lại 8 phản hồi 304; 13 test offline pass. Có 4 file dùng host robots trả 403, ghi rõ bounded probe, không đánh dấu Allow. Khảo sát OCR cũ đối chiếu sáu trường ở hai PDF, chưa gold độc lập. Bốn HTML cổ tức VNM/DHG có năm thành phần năm lợi nhuận; chưa chứng minh lịch sử năm đủ hoặc đã thực trả.

Chưa có ứng dụng hoàn chỉnh, dataset lịch sử ghép đầy đủ hoặc benchmark độc lập. Prototype chưa tự thu 2023–2024; cần mở cấu hình kỳ và adapter cổ tức. Đọc [bằng chứng crawl](../research-crawl-methods/README.md) và [sự kiện](../research-recent-data/dividend-event-examples.json).

## Tài liệu các hướng đã khảo sát

Hồ sơ A1–A7 trong ideas là thư viện tham khảo. [A2](ideas/a2-bctc-co-tuc/01-y-tuong-va-kha-thi.md) là hướng chọn; các hướng khác không triển khai song song. Bản A1 trước được giữ ở [snapshot lịch sử](history/a1-2026-10-03.zip). Quy tắc MVP mới nằm trong bộ này; các ngưỡng cảnh báo/nhãn dự báo 12 tháng của tài liệu cũ không tự áp dụng.
