# Đề tài và đặc tả hiện hành

Phiên bản **2.0 ngày 03/10/2026**, sau lựa chọn của người thực hiện. Tên:
**Xây dựng hệ thống thu thập và phân tích mối quan hệ giữa lợi nhuận, dòng tiền và cổ tức tiền mặt của doanh nghiệp niêm yết Việt Nam.**

## 1 Bài toán và người dùng

Người đọc muốn thấy mức cổ tức công bố biến động cùng lợi nhuận và dòng tiền ra sao, với bằng chứng đúng doanh nghiệp/kỳ/phạm vi. Luồng sử dụng: chọn doanh nghiệp → xem mức đầy đủ → xem chuỗi năm và timeline → đọc chỉ số/case → mở trang nguồn. Người vận hành kiểm tra candidates, sự kiện điều chỉnh, năm lợi nhuận và sửa có audit.

Phân tích là lịch sử/mô tả, không xác suất duy trì cổ tức, đánh giá khả năng thanh toán pháp lý, nhân quả hoặc khuyến nghị mua bán.

## 2 Scope dữ liệu

Pilot 3 doanh nghiệp × 2023–2025 = 9 BCTC năm và các thông báo liên quan. Mục tiêu mở rộng 5–8 doanh nghiệp, 15–24 BCTC năm sau gate tuần 4. Sáu trường lõi: net_income_total, cfo, cash_equivalents, total_assets, total_liabilities, total_equity. EPS, LNST cổ đông mẹ, doanh thu, nợ vay, capex và ngắn hạn chỉ thêm nếu cần câu hỏi cụ thể và có dữ liệu đúng.

Ưu tiên phi tài chính, BCTC năm kiểm toán và series hợp nhất khi có. Báo cáo cấp doanh nghiệp phải được xác nhận; scope khác được tách cohort/series, không gộp tùy tiện. BCTC riêng công ty mẹ dùng làm bối cảnh khi thu được, không bắt buộc tải đôi toàn mẫu.

Đích cổ tức: **mức tiền mặt được công bố trên mỗi cổ phiếu và năm lợi nhuận**. Sự kiện có ngày công bố, chốt quyền, lịch thanh toán, trạng thái sửa/hủy. Paid confirmation là optional có bằng chứng; ngày thanh toán đã qua không đủ để gán paid. Một case 2026 có thể dùng chứng minh cập nhật.

## 3 Yêu cầu MVP

| Mã | Chức năng | Nghiệm thu |
|---|---|---|
| PF01 | Công ty/kỳ/coverage | Expected ledger với lý do missing, trạng thái source/scope |
| PF02 | Tự thu BCTC và sự kiện | Ít nhất một adapter tự phát hiện danh mục BCTC và một luồng tự phát hiện thông báo cổ tức; seed danh mục/search hợp lệ, không seed từng file như bằng chứng tự phát hiện; fallback nhập ghi riêng |
| PF03 | Trích và chuẩn hóa | Sáu financial targets; event/components; raw value, unit, period, scope, source hash và locator |
| PF04 | Validation/review | Trước/sau/lý do, không xuất candidate chưa duyệt như fact đúng |
| PF05 | Lưu phiên bản | SQLite constraints/transaction; chạy lại không trùng; nguồn sửa có lịch sử |
| PF06 | Ghép doanh nghiệp–năm | DPS quan sát và trạng thái đủ dữ liệu riêng; năm lợi nhuận khác năm lịch; sửa/hủy không cộng trùng |
| PF07 | Phân tích mối quan hệ | Xu hướng, CFO/LNST hợp lệ, tiền/nợ trên tài sản, DPS biến động khi tương thích; số mẫu và giới hạn |
| PF08 | Dashboard/export | Timeline và chart, mở nguồn/operand, chất lượng, snapshot CSV/JSON |
| PF09 | Demo và đánh giá | File/thông báo mới qua luồng, lỗi được phát hiện, baseline/holdout và ba case |

Tự crawl cổ tức đầy đủ là gate chưa vượt, dù bốn thông báo mẫu đã trích được. Khi nguồn chỉ cho phép nhập có provenance, báo rõ tỷ lệ và hạn chế; không nghiệm thu PF02 như đã tự phát hiện. Không cần FastAPI/React hoặc nhiều người dùng trong MVP. Stack một app Python/Streamlit/SQLite.

## 4 Đóng góp IT

Adapter/rate-limit/retry/conditional GET, xử lý PDF scan, parser metadata và bảng, event identity/lifecycle, mô hình nhiều thành phần năm lợi nhuận, coverage và review audit, phép tính có operands, UI truy vết và kiểm thử. Đo chất lượng dữ liệu và công sức là bằng chứng chính. Rubric của trường vẫn cần đối chiếu; không chỉ dùng tên thư viện để kết luận đạt IT.

## 5 Câu hỏi và gate

RQ1: Collector chọn đúng/tải được bao nhiêu tài liệu và sự kiện đã công bố trên expected set?
RQ2: Text-only so OCR/parser/review cải thiện đúng joint và công sức thế nào?
RQ3: Chuỗi lợi nhuận–CFO–DPS có những quan hệ/ngoại lệ mô tả nào trên mẫu đủ dữ liệu?
RQ4: Kết quả có tái tính và truy nguồn/phiên bản được không?

100% giá trị xuất bản có provenance, kỳ/unit/scope; tổng DPS năm chỉ được gọi đầy đủ khi ledger được review. Gate tuần 4 quyết định scope; tuần 8 freeze holdout. Ngưỡng accuracy mục tiêu thăm dò 95% trước review cần chấm trên target đã freeze, không phải kết quả đạt. Thống kê nhỏ không trở thành bằng chứng nhân quả.

Phương pháp chi tiết: [thu thập/xử lý](11-phuong-phap-thu-thap-va-xu-ly.md), [ghép/phân tích](13-ghep-co-tuc-va-phan-tich.md).
