# Protocol đánh giá và nghiệm thu

Thiết kế hiện hành ngày 03/10/2026, chưa có kết quả nghiệm thu. Đánh giá thu thập, trích/ghép dữ liệu và ứng dụng; không chấm predictor trong project.

## 1 Expected và holdout

Freeze issuer/year/scope, sáu financial targets/report, các fields/events/components gold và cửa sổ nguồn đã rà. Bốn notices mẫu và PDF dùng chỉnh parser thuộc development. Holdout dùng tài liệu/notices khác, tránh cùng notice route, bản dịch hoặc phiên bản gần giống ở hai tập. Gold có người khác kiểm tra nếu có; tự chấm phải nói rõ.

Scope mục tiêu 15–24 BCTC năm; gợi ý 5–8 tài liệu holdout ×6 targets =30–48 ô, cộng event holdout theo nguồn/kỳ đã chọn. Cỡ mẫu chốt sau pilot, không bảo đảm lực thống kê. Nếu ít hơn, báo mẫu nhỏ. Không bỏ target missing khỏi mẫu số.

## 2 Metrics riêng

| Lớp | Số đo |
|---|---|
| Discovery/selection | Expected đã công bố, coverage và precision đúng loại/kỳ/scope sau kiểm tra |
| Download/update | PDF/HTML hợp lệ, policy-skip/errors, bytes và phiên bản trước/sau/304 |
| Financial extraction | Joint metric/value/unit/period/scope, missing, lỗi trước/sau review |
| Events/components | Ticker/kind/DPS/profit_year/dates đúng joint, precision/recall theo gold |
| Lifecycle/aggregate | Trùng/sửa/hủy đúng, annual complete/partial/unknown và share comparability |
| Effort | Giây các bước, phút review tài liệu/notice, công sức sửa adapter |
| App | Truy ngược nguồn/operands, export tái lập, failure hiển thị rõ |

B0 text-only, B1 text + OCR fallback + parser cột, B2 B1 + validation/review. Không gọi B2 là accuracy tự động. Event parser có baseline một năm/notice để thấy lợi ích components nhưng không xuất baseline sai như dataset chính.

Financial VND integer dùng exact match; nguồn làm tròn thì tolerance công bố trước. Coverage có cả source failures và unknown. Báo tỷ lệ cùng số đếm/cỡ mẫu. Khi nói tiết kiệm công sức, cần đo nhập tay tương đương và giới hạn người đã nhớ số.

## 3 Tests nghiệp vụ

Normalize: dấu ngoặc âm, nghìn/triệu, gạch/ô trống. Period/scope: YTD vs riêng quý, hợp nhất/riêng, số so sánh. Event: notice hai năm, hai route, hai nguồn cùng đợt, hai đợt cùng số; sửa lịch không thêm DPS; sửa mức/hủy giữ lịch sử; thiếu notice không là 0; share basis chưa rõ chặn tổng/growth. JOIN không nhân bản facts theo số components.

Store: keys/transaction/audit/rollback, chạy lại không trùng và snapshot cũ còn nguyên khi bản mới tới. Collector: HTML giả PDF, timeout/404/policy/redirect/corrupt cache. E2E: BCTC + notice thật tới review/aggregate/chart/export và mở nguồn ngược.

## 4 Nghiệm thu và bằng chứng trước

100% số xuất bản có source hash/version/locator/kỳ/unit/scope, active components/coverage. Ba case có dữ liệu và giới hạn; ERD/architecture, test/benchmark, README chạy, báo cáo Word/slide và demo tự giải thích/sửa nhỏ. Một luồng discovery BCTC và một luồng discovery event phải có log; manual fallback đếm riêng.

Crawler đã có 8 PDF/4 issuer/7 HTML và 8 ×304, 13 test offline; đây là development, không accuracy thị trường hoặc dataset ghép hoàn chỉnh. [Bằng chứng](../research-crawl-methods/crawl-evidence.json) không đổi số sau đổi scope. Numeric OCR cũ 11/12 chỉ mẫu sáu trường, không independent gold.

Tương quan/case không được nghiệm thu như mô hình dự đoán. Rubric trường chưa có nên phải đối chiếu với thầy, đặc biệt yêu cầu AI nếu thật sự bắt buộc.
