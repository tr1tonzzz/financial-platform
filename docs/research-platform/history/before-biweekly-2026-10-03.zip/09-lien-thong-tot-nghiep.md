# Liên thông lên dự đoán cổ tức tiền mặt

Hướng nối tiếp duy nhất ưu tiên: **dự đoán duy trì hoặc giảm mức cổ tức tiền mặt được công bố**, dùng dữ liệu lợi nhuận/dòng tiền và lịch sử sự kiện có truy vết. Project hiện tại chỉ phân tích mô tả. Tên/rubric/thời gian tốt nghiệp cần trao đổi sau, chưa bảo đảm liên thông tự động.

## 1 Tái sử dụng

Collector/raw/version, financial facts đã review, event components/lifecycle/basis, coverage/snapshots, schema, tests và UI. Chưa cần chuyển sang hỏi đáp AI hoặc xây nhiều hướng song song.

## 2 Protocol dự đoán phải chốt trước mô hình

Phương án ưu tiên để kiểm tra: cutoff là ngày BCTC năm được xác nhận khả dụng; features chỉ dùng thông tin đã biết tại cutoff. Target là thay đổi tổng DPS **công bố trong 12 tháng sau cutoff** so cửa sổ so sánh trước, trên basis đã xử lý. Đây khác bảng profit_year hồi cứu của project. Ngưỡng giảm là tham số chốt trước test sau pilot, chưa mặc định 30%.

Nếu chọn target theo năm lợi nhuận tiếp theo, phải lập protocol mới và xử lý tạm ứng/các thông báo đến muộn; không hoán đổi hai target sau xem kết quả. Chỉ làm một định nghĩa chính trong luận văn.

Nhãn censored khi cửa sổ chưa khép; unknown khi không đủ coverage/basis; absence không là omission/zero. Một BCTC FY2025 công bố tháng 3/2026 có window đến tháng 3/2027 nên tại 03/10/2026 chưa trưởng thành. Thông báo lịch trả không là thực trả, target tên công bố phải nhất quán.

## 3 Điều kiện khả thi

Cần nhiều năm/issuer hơn 15–24 quan sát hiện tại, đủ trường hợp giảm và đủ quality/point-in-time dates. Cohort toàn công ty trả đều sẽ khó đánh giá lớp giảm; pilot phải kiểm tra label distribution và công sức mở rộng trước cam kết mô hình.

Share changes, restated facts và bản thay thế sau cutoff không được đưa ngược vào feature lịch sử. Nguồn chỉ biết ngày công bố hiện tại hoặc thiếu version lịch sử phải ghi giới hạn point-in-time, không giả định lịch sử hoàn hảo.

## 4 Baseline và đánh giá tương lai

Baseline lịch sử giữ mức/carry-forward theo target đã định nghĩa; sau đó Logistic Regression hoặc cây đơn giản nếu sample/lớp đủ. Chia thời gian trước/sau và xử lý cửa sổ trùng; không random split các kỳ/cùng phiên bản gây leakage. Đo precision/recall/F1/PR-AUC với lớp giảm, calibration nếu dùng xác suất, số mẫu và uncertainty.

Đánh giá chất lượng extraction và nhãn riêng trước model. Chỉ nói model hữu ích sau so baseline trên holdout; không hứa dự đoán chính xác hoặc đề xuất đầu tư. Các mô hình/framework chỉ chốt khi tới giai đoạn này.
