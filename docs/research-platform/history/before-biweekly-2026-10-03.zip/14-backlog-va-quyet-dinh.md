# Backlog triển khai và sổ quyết định

## Quyết định đã thống nhất ngày 03/10/2026

| ID | Quyết định | Lý do |
|---|---|---|
| D01 | Một ngách lợi nhuận–CFO–cổ tức tiền mặt | Người thực hiện muốn tập trung và liên thông lên dự đoán |
| D02 | Project phân tích mô tả, predictor để tốt nghiệp | Nền học và dữ liệu chưa đủ cho mô hình |
| D03 | Target là DPS công bố theo profit_year | Nguồn đang có là thông báo/lịch, chưa payment confirmation |
| D04 | Sáu financial targets lõi | Đã có mẫu phát triển; giảm phần ngoài câu hỏi chính |
| D05 | Pilot 3 × 3 năm; gate 5–8 doanh nghiệp | Quỹ 13 tuần, 10–12 giờ/tuần gồm học/report |
| D06 | Python HTTP/lxml, text/OCR, SQLite, Streamlit | Một stack dễ tự giải thích; mở framework khi thật cần |
| D07 | Human review metadata/closure/số có audit | Không giả định crawl và OCR luôn đúng |
| D08 | Hợp nhất ưu tiên, entity tách scope | Không trộn riêng/hợp nhất hoặc suy khả năng chi tiền mẹ từ nhóm |

Đây là quyết định của người thực hiện và phương pháp triển khai; chưa có xác nhận giảng viên/rubric/hạn thực.

## Việc làm tiếp theo theo phụ thuộc

| Thứ tự | Đầu ra | Tiêu chí xong |
|---|---|---|
| T01 | Chọn 3 issuer và source/expected ledger | Đủ nguồn BCTC/sự kiện, scope chính và lý do chọn |
| T02 | Một vertical slice | BCTC + notice thật tới candidates/review/aggregate; đọc được source |
| T03 | Discovery cổ tức | Tự tìm nhiều notice từ trang công khai, giữ tuyến discovery và pagination |
| T04 | Mở collector kỳ 2023–2025 | Bỏ fixed FY2025/H1 filter theo config, giữ regression tests |
| T05 | Pilot 9 BCTC + sự kiện | Sáu target/report, events/components, missing và phút review |
| T06 | SQLite/UI review | Keys/transaction, source/event versions và audit |
| T07 | Dashboard ba case | Chuỗi đủ/comparable, timeline, provenance/export |
| T08 | Holdout và report | Baselines, metrics, giới hạn, Word/slide thống nhất |

T01–T08 là backlog tương lai; không tick hoàn thành bằng việc đã có tài liệu. Chưa cần predictor/API/React hoặc tự tạo lịch gửi thầy. Người thực hiện tự giải thích một module mỗi tuần.

## Gate thu hẹp

Tuần 2: một luồng nguồn tới dữ liệu phải chạy; event discovery thất bại thì thử IR adapter chính thức trước, báo phần assisted riêng. Tuần 4: đo thời gian pilot rồi chốt số issuer, không đổi missing thành 0. Tuần 8: freeze scope/holdout. Tuần 11: feature freeze. Nếu hạn/giờ thực khác giả định, lập lại ngân sách.

## Lịch sử

A1 sức khỏe tài chính là quyết định trước, [snapshot](history/a1-2026-10-03.zip). Các forecast score/threshold từ bộ initial-docs cũ là nghiên cứu lịch sử, không hiện hành. Khi đổi target/scope/nguồn phải ghi ngày, lý do, tác động dữ liệu và cập nhật SRS cùng Word/slide.
