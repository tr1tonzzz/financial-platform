# Báo cáo đề xuất hiện hành

Ngày thống nhất 03/10/2026, đề tài lợi nhuận–dòng tiền–cổ tức tiền mặt. Hai file cùng phương pháp với SRS v2, scope pilot 3×3 năm, mục tiêu 5–8 công ty và sáu financial targets.

- [Báo cáo Word](bao-cao-de-xuat.docx).
- [Slide đề xuất](de-xuat-project.pptx).
- [Nội dung chung để tái tạo](noi-dung-de-xuat.json).

Đây là báo cáo định hướng/dữ liệu đã thử, không báo cáo đã hoàn thành các tuần hoặc đã có predictor/app. Nguồn/số đếm thật có ở nghiên cứu crawler và sự kiện mẫu. Mỗi tuần sau tạo bộ riêng theo [quy trình](../07-bao-cao-hang-tuan.md), không tạo tiến độ giả.

Word/slide A1 trước nằm trong [snapshot](../history/a1-2026-10-03.zip). Không dùng làm proposal hiện hành.
