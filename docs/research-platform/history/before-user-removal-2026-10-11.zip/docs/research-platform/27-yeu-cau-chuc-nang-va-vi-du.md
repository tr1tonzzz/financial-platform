# Yêu cầu chức năng của hệ thống — mục đích, cách sử dụng và ví dụ

Phiên bản 1.1 • Ngày 11/10/2026 • Đối chiếu SRS-FAP-01 v3.2 và nghiên cứu hướng nền tảng dữ liệu.

Tài liệu này trình bày **năm chức năng chính theo mục tiêu người dùng**, giải thích chúng phục vụ việc gì và kết quả người dùng nhận được. Các thao tác thu thập, trích xuất, chuẩn hóa, kiểm tra và duyệt nằm bên trong các chức năng chính. Khi triển khai, từng thao tác được làm thành các UC nhỏ để hoàn thiện chức năng lớn.

**Định vị:** nền tảng cần cho người dùng khai thác bộ dữ liệu tài chính để xem xu hướng, so sánh, tìm trường hợp cần chú ý và tiếp tục nghiên cứu. Quản lý báo cáo là phần tạo dữ liệu có bằng chứng. Năm BUC dưới đây được giữ theo SRS; phần phân tích đã có yêu cầu được giải thích rõ hơn ở mục 2.1, các ý tưởng tương tác/chức năng bổ sung được đánh dấu riêng ở mục 2.2.

**Cách đọc trạng thái:** “Yêu cầu nền” là nội dung đã có trong đặc tả trước; “Bổ sung” là nội dung mới đưa vào dự thảo v3.2. Cả hai đều mô tả hệ thống cần xây dựng, không có nghĩa đã hoàn thành. Hiện đã có các prototype nghiên cứu, chưa có ứng dụng hoàn chỉnh. Các ví dụ về công ty A, B, C và số tiền dưới đây đều **giả định để giải thích**, không phải đánh giá doanh nghiệp thật.

## 1. Danh mục chức năng chính

| Mã UC lớn | Chức năng | Câu hỏi người dùng được hỗ trợ trả lời |
|---|---|---|
| BUC01 | Quản lý hồ sơ dữ liệu doanh nghiệp | Tôi đã có những tài liệu và số liệu nào? Chúng có đủ, đúng và kiểm tra lại được không? |
| BUC02 | Đánh giá nền tảng tiền mặt cho cổ tức | Doanh nghiệp có lãi nhưng tạo ra bao nhiêu tiền? Tiền kinh doanh có bao phủ các khoản chi đang xem xét không? |
| BUC03 | Tra soát lịch sử chính sách và quyền cổ tức | Cổ tức thuộc năm nào, đang có hiệu lực ra sao và có thể so sánh qua các năm không? |
| BUC04 | Sàng lọc và đối chiếu ứng viên cổ tức | Trong tập doanh nghiệp theo dõi, hồ sơ nào đáp ứng tiêu chí và hồ sơ nào cần đọc sâu hơn? |
| BUC05 | Quản lý hồ sơ thẩm định cổ tức | Tôi nhận xét điều gì, dựa vào nguồn nào và còn phải kiểm tra việc gì? |

Người sử dụng có thể đồng thời là người nhập/duyệt dữ liệu và người phân tích. “Thẩm định” trong tài liệu nghĩa là đọc, kiểm tra và đánh giá bằng chứng trước khi tự quyết định; hệ thống không thay người dùng đưa ra quyết định đầu tư.

## 2. Một số từ cần hiểu trước

| Thuật ngữ | Giải thích đơn giản |
|---|---|
| Báo cáo tài chính — BCTC | Tài liệu thể hiện tình hình tài chính, kết quả kinh doanh và dòng tiền của doanh nghiệp |
| Lợi nhuận sau thuế — LNST | Số lãi/lỗ sau thuế được ghi nhận theo kế toán; không đồng nghĩa với số tiền đang có |
| Dòng tiền kinh doanh — CFO | Tiền thuần tạo ra hoặc sử dụng bởi hoạt động kinh doanh trong kỳ |
| Chi đầu tư — CAPEX trong chức năng này | Khoản tiền chi mua sắm/xây dựng tài sản cố định và tài sản dài hạn theo dòng nguồn đã xác nhận; phải ghi rõ phạm vi khoản chi |
| Cổ tức tiền mặt trên mỗi cổ phiếu — DPS | Số đồng công bố cho một cổ phiếu đủ quyền nhận cổ tức |
| Năm lợi nhuận | Năm mà khoản cổ tức được phân phối theo thông báo; có thể khác năm công bố hoặc năm thanh toán |
| Phạm vi báo cáo | Báo cáo của riêng công ty hoặc báo cáo hợp nhất công ty và các đơn vị thuộc phạm vi hợp nhất; không trộn hai phạm vi để tính tỷ số |
| Cơ sở cổ phiếu | Cách xác định một cổ phiếu khi đọc DPS, trước hoặc sau các sự kiện làm thay đổi số cổ phiếu |
| Mốc dữ liệu | Thời điểm chốt những thông tin được dùng trong một lần phân tích |
| Bản dữ liệu chốt — snapshot | Bản lưu số liệu, nguồn, công thức và điều kiện phân tích để mở lại, tính lại về sau |

“Tra cứu nguồn” là tìm/xem tài liệu. “Đối chiếu” là kiểm một số hoặc kết quả với bằng chứng. “Tra soát” là kiểm tra vấn đề hoặc sai lệch để làm rõ; dùng thuật ngữ này khi có nội dung cần xác minh, không chỉ vì có nút mở PDF.

### 2.1. Phần phân tích đã có yêu cầu gồm những gì?

Hệ thống cần hỗ trợ **bảng, biểu đồ và bộ lọc**, không chỉ trả kết quả tính tỷ số. Các nội dung dưới đây đã có trong SRS v3.2; chưa có giao diện hoàn chỉnh đã chạy.

| Người dùng cần làm | Hệ thống hỗ trợ bằng gì? | Ví dụ đơn giản | Yêu cầu nền |
|---|---|---|---|
| Theo dõi tài chính qua các năm | Bảng/biểu đồ LNST, CFO và biến động | Nhìn thấy lãi tăng nhưng tiền kinh doanh giảm | FR25, FR32 |
| Đọc lợi nhuận cùng dòng tiền | CFO/LNST khi đủ điều kiện, công thức và lý do khi không tính | LNST 100 tỷ, CFO 80 tỷ: tỷ số 0,8 | FR26, FR31 |
| Xem hai khía cạnh của cơ cấu tài chính | Tỷ trọng tiền/tài sản và nợ phải trả/tài sản | Tỷ trọng tiền giảm giữa hai năm; người dùng biết cần đọc thêm | FR27, FR32 |
| Theo dõi lịch sử cổ tức | Timeline sự kiện và mức DPS theo năm hợp lệ | Đợt thanh toán năm 2026 vẫn có thể thuộc lợi nhuận 2025 | FR19–FR24, FR28, FR32 |
| Tìm trường hợp cần chú ý | Bộ lọc “LNST tăng, CFO giảm” hoặc “DPS giữ/tăng, LNST hoặc CFO giảm” | Thu hẹp danh sách cần đọc từ điều kiện cụ thể | FR29 |
| Khám phá quan hệ giữa chỉ tiêu | Scatter và Spearman có điều kiện/số mẫu/giới hạn | Xem vị trí doanh nghiệp trong tập dữ liệu đang xét, chưa suy ra quan hệ nhân quả | FR30 |
| Kiểm lại và dùng lại phân tích | Đi từ kết quả tới số/nguồn; xuất và tái tính snapshot | Mở lại lần phân tích để kiểm kết quả dù dữ liệu hiện hành đã sửa | FR31, FR34–FR35 |

Tiền của doanh nghiệp và DPS có đơn vị/trục riêng; ô thiếu để trống có lý do. Bộ ba năm của pilot dùng để quan sát và trình diễn, chưa đủ đánh giá xu hướng dài hạn. Giá chứng khoán chưa có trong nguồn dữ liệu MVP nên chưa cam kết biểu đồ giá.

### 2.2. Các chức năng cần phát triển rõ hơn sau nghiên cứu mới

Đây là **đề xuất**, có phần tái sử dụng yêu cầu nền và có phần bổ sung; chưa tạo mã FR mới hoặc tự mở rộng SRS.

| Ý tưởng | Mục đích | Ví dụ người dùng làm được |
|---|---|---|
| Khám phá bộ dữ liệu | Lấy đúng số liệu cần dùng từ nhiều công ty/kỳ | Chọn A/B, 2023–2025, LNST/CFO; xem bảng và xuất cùng nguồn |
| Dashboard phân tích tương tác | Đi từ xu hướng đến kỳ/số liệu cần đọc sâu | Chọn một năm trên biểu đồ, bảng và vùng chi tiết cùng chuyển về năm đó |
| So sánh doanh nghiệp song song | Đọc khác biệt trên cùng cơ sở | Đặt CFO/LNST của A và B cùng năm cạnh nhau, xem định nghĩa và nguồn |
| Liên kết sàng lọc với biểu đồ/chi tiết | Tìm trường hợp rồi đọc tiếp ngay trong bối cảnh đã chọn | Lọc “lãi tăng, CFO giảm”, chọn A trong kết quả để xem năm liên quan |
| Phân rã chênh lệch tiền | Biết khoản nào cần kiểm tra tiếp | Từ CFO giảm đi tới dòng phải thu đóng góp vào thay đổi, nếu mapping đủ |
| Kết hợp lịch sử cổ tức với sự kiện | Tránh nhầm năm và cơ sở cổ phiếu | Xem đợt quyền và DPS gốc/tham chiếu trong cùng lần phân tích |
| Theo dõi doanh nghiệp và thay đổi | Biết dữ liệu mới ảnh hưởng chỗ nào đã đọc | CFO sửa 120→125; xem bản trước/sau và phép tính liên quan |
| Lưu không gian phân tích | Tiếp tục công việc với đúng dữ liệu và điều kiện | Mở lại A/B, bộ lọc, biểu đồ, bản chốt và ghi chú hôm trước |

[Nghiên cứu hướng sản phẩm](../research-financial-platform-direction/README.md) trả lời nguy cơ lệch sang quản lý báo cáo; [mô tả từng chức năng và tính khả thi](../research-financial-platform-direction/02-chuc-nang-phan-tich-va-kha-thi.md) ghi dữ liệu, ví dụ và tác vụ hoàn chỉnh. G02/G03/G01 được kế thừa vào các ý tưởng này.

## 3. BUC01 — Quản lý hồ sơ dữ liệu doanh nghiệp

### 3.1. Mục đích và cách hiểu đơn giản

Giúp người dùng có một bộ hồ sơ đầy đủ theo doanh nghiệp và năm, biết số nào đã được kiểm tra, số nào còn thiếu và mỗi số lấy từ đâu. Chức năng này giảm việc tìm tài liệu và nhập số lặp lại, đồng thời tạo dữ liệu đáng tin cậy để các chức năng phân tích sử dụng.

**Hiểu đơn giản:** một bộ số liệu tài chính có thể tra cứu và dùng lại, mỗi số biết lấy từ đâu và đã kiểm tra đến đâu. Người dùng chọn công ty/năm để lấy dữ liệu phục vụ phân tích; các tài liệu được giữ làm bằng chứng của bộ số liệu đó.

### 3.2. Hệ thống cần thực hiện những gì?

| Thành phần chức năng | Yêu cầu và kết quả người dùng nhận được | Ví dụ dễ hiểu |
|---|---|---|
| Thiết lập hồ sơ theo doanh nghiệp/năm | Cho chọn doanh nghiệp, năm và phạm vi; liệt kê tài liệu/chỉ tiêu cần có và tình trạng thiếu | Chọn công ty A trong 2023–2025; hệ thống báo còn thiếu BCTC 2023 |
| Thu thập và cập nhật tài liệu | Tìm/tải BCTC, thông báo cổ tức từ nguồn chính thức trong phạm vi cấu hình; cho nhập hỗ trợ có nguồn; báo lỗi từng tài liệu | Đã có BCTC 2024, khi thu được bản sửa thì giữ cả bản cũ và bản mới |
| Trích xuất và chuẩn hóa | Đọc số liệu/nội dung quyền, nhận diện kỳ và đơn vị, quy đổi về đơn vị thống nhất; số chưa rõ được đánh dấu | Nguồn ghi “120 triệu đồng”, hệ thống lưu 120.000.000 đồng và vẫn giữ cách ghi gốc |
| Kiểm tra và duyệt | Cho người vận hành xem số cạnh nguồn, sửa/duyệt/từ chối có lý do; chỉ số được duyệt mới vào phân tích chính thức | Máy đọc nhầm 80 thành 800; người vận hành sửa theo trang nguồn, lịch sử giữ lần sửa |
| Quản lý phiên bản và bằng chứng | Lưu nguồn, vị trí số, phiên bản và lịch sử quyết định; hỗ trợ xuất hồ sơ kiểm chất lượng, sao lưu và phục hồi | Người dùng xem một kết quả và truy tới đúng trang chứa số đầu vào |

### 3.3. Đầu vào → xử lý → đầu ra

- **Đầu vào:** doanh nghiệp, giai đoạn, nguồn BCTC/thông báo, tài liệu tải về hoặc nhập hỗ trợ.
- **Xử lý:** lập danh mục cần có → thu thập → đọc/chuẩn hóa → kiểm tra → người vận hành duyệt → lưu hồ sơ và phiên bản.
- **Đầu ra:** bộ số liệu đã duyệt, tài liệu nguồn và danh sách còn thiếu/chưa giải quyết.

**Ví dụ:** A cần ba BCTC năm và các thông báo cổ tức liên quan. Nếu đã thu đủ ba báo cáo nhưng một số CFO chưa được duyệt, hệ thống phải hiển thị “CFO 2025 đang chờ duyệt”. Chức năng phân tích không lấy số đó như đã xác nhận, cũng không thay nó bằng 0.

**Khi nào coi là hoàn thành?** Người dùng sử dụng được bộ dữ liệu đã kiểm tra và biết phần còn thiếu. Chỉ tải được tài liệu chưa đủ để hoàn thành UC này.

**Phạm vi yêu cầu:** nền FR01–FR18, FR33, FR36–FR38. Khi chọn chức năng mới, luồng này còn hỗ trợ nhập/duyệt CAPEX, khoản thực chi và sự kiện cổ phiếu theo D01/D05.

Đầu ra được khai thác qua tra cứu/biểu đồ FR32 và xuất dữ liệu FR34; không kết thúc ở việc có một danh sách PDF. Bộ chọn dữ liệu nhiều doanh nghiệp/chỉ tiêu ở mục 2.2 là phần tương tác đề xuất.

## 4. BUC02 — Đánh giá nền tảng tiền mặt cho cổ tức

### 4.1. Mục đích và cách hiểu đơn giản

Giúp người dùng xem lợi nhuận đi cùng dòng tiền như thế nào và khoản tiền từ kinh doanh có bao phủ chi đầu tư, phân phối cho chủ sở hữu trong kỳ hay không. Qua đó, người dùng biết điểm nào cần đọc sâu trước khi đánh giá chính sách cổ tức.

**Hiểu đơn giản:** một cửa hàng có lãi trên sổ sách vẫn có thể thiếu tiền do khách chưa thanh toán, mua thêm hàng hoặc mua máy móc. Cần xem tiền vào/ra bên cạnh số lãi, rồi mới xem phần tiền còn lại sau những khoản chi được chọn.

### 4.2. Hệ thống cần thực hiện những gì?

| Thành phần chức năng | Yêu cầu và kết quả người dùng nhận được | Ví dụ dễ hiểu |
|---|---|---|
| Đối chiếu lợi nhuận và dòng tiền qua các năm | Hiển thị bảng/biểu đồ LNST, CFO, mức tăng/giảm và CFO/LNST khi đủ điều kiện | LNST tăng từ 90 lên 100 tỷ, CFO giảm từ 130 xuống 120 tỷ: người đọc thấy hai đại lượng khác chiều |
| Xem cơ cấu tiền và nợ phải trả | Hiển thị tiền/tài sản và nợ phải trả/tài sản với nhãn đúng | Nợ phải trả 40 tỷ trên tài sản 100 tỷ là 40%; không gọi toàn bộ 40 tỷ là nợ vay |
| Xem cầu nối lợi nhuận trước thuế tới CFO | Với ca được chọn, trình bày các dòng điều chỉnh đã duyệt và phần chênh lệch chưa giải thích được | Lợi nhuận trước thuế 100 tỷ, cộng khấu hao 10 tỷ và biến động khác −30 tỷ cho CFO 80 tỷ; nếu thiếu dòng thì ghi chưa giải thích đầy đủ |
| Phân tích tiền sau chi đầu tư và phân phối — **bổ sung G02** | Tính CFO−CAPEX, CFO−CAPEX−khoản thực chi và tỷ số bao phủ khi hợp lệ; ghi rõ loại khoản thực chi | CFO 120, chi đầu tư 80, trả cổ tức 60 tỷ: còn −20 tỷ sau hai khoản chi |
| Tra soát kết quả | Cho xem công thức, số đầu vào, nguồn và giới hạn; giúp ghi câu hỏi cần kiểm tra tiếp | Từ số dư −20 tỷ, người dùng kiểm tra tiền tích lũy và các hoạt động tài trợ trong báo cáo |

### 4.3. Đầu vào → xử lý → đầu ra

- **Đầu vào:** số liệu tài chính đã duyệt cùng kỳ/phạm vi; dòng cầu nối và khoản chi bổ sung khi có.
- **Xử lý:** kiểm điều kiện → tính xu hướng/tỷ số → tính cầu nối/bao phủ theo dữ liệu hợp lệ → giải thích kết quả.
- **Đầu ra:** bảng/biểu đồ đối chiếu, số dư sau khoản chi, bằng chứng và vấn đề cần tra soát.

**Ví dụ:** A có LNST 100 tỷ và CFO 120 tỷ. Chỉ nhìn hai số này thấy CFO cao hơn LNST. Nhưng nếu A chi đầu tư 80 tỷ và thực trả cổ tức 60 tỷ trong cùng kỳ/phạm vi thì:

`120 − 80 − 60 = −20 tỷ đồng`.

Hệ thống cần nêu “CFO kỳ này chưa bao phủ hai khoản chi được chọn”. Người đọc cần kiểm tra thêm bối cảnh; kết quả không tự chứng minh A vay để trả cổ tức hoặc sắp giảm cổ tức.

**Điều kiện quan trọng:** cổ tức công bố cho năm lợi nhuận 2025 không tự bằng tiền cổ tức đã chi trong năm tài chính 2025. Nếu báo cáo ghi gộp “cổ tức, lợi nhuận trả cho chủ sở hữu”, phải giữ đúng nhãn khoản gộp. Thiếu CAPEX vẫn xem được LNST/CFO, nhưng chưa tính được tiền sau CAPEX.

**Phạm vi yêu cầu:** nền FR25–FR27; cầu nối theo E01–E10; G02 theo D01–D04, bổ sung cho các ca được chọn.

## 5. BUC03 — Tra soát lịch sử chính sách và quyền cổ tức

### 5.1. Mục đích và cách hiểu đơn giản

Giúp người dùng đọc đúng lịch sử cổ tức: khoản nào thuộc năm lợi nhuận nào, thông báo nào còn hiệu lực, lịch thanh toán ra sao và mức trên mỗi cổ phiếu có so sánh được không.

**Hiểu đơn giản:** một “sổ cổ tức” có giải thích. Hệ thống không chỉ cộng số tiền ghi trong thông báo; còn kiểm tra khoản đó thuộc năm nào, có bị sửa/hủy hay đăng trùng, và cổ phiếu trước/sau biến động có cùng cơ sở hay không.

### 5.2. Hệ thống cần thực hiện những gì?

| Thành phần chức năng | Yêu cầu và kết quả người dùng nhận được | Ví dụ dễ hiểu |
|---|---|---|
| Ghép cổ tức với đúng năm lợi nhuận | Tách các thành phần của thông báo và tổng hợp đúng năm khi đủ cơ sở | Thông báo đăng năm 2026 nói trả phần còn lại của 2025: khoản đó vào lịch sử lợi nhuận 2025 |
| Xử lý thông báo trùng, sửa và hủy | Liên kết cùng đợt, giữ lịch sử và xác định bản có hiệu lực; không cộng trùng | Một đợt 1.000 đồng xuất hiện ở hai nguồn vẫn chỉ tính một lần sau khi xác nhận cùng đợt |
| Theo dõi lịch và trạng thái thực hiện quyền | Hiển thị ngày công bố, ngày đăng ký cuối cùng, lịch trả và thay đổi; phân biệt dự kiến với xác nhận thanh toán | Qua ngày dự kiến trả vẫn chưa tự ghi “đã thanh toán” nếu thiếu bằng chứng |
| Kiểm độ đầy đủ trước khi so sánh | Hiện phần quan sát được; chỉ kết luận biến động cổ tức năm khi đã rà đủ nguồn theo mốc dữ liệu và basis phù hợp | Mới tìm được một đợt 500 đồng không có nghĩa cả năm chỉ chia 500 đồng |
| Tra soát cơ sở cổ phiếu — **bổ sung G03** | Giữ DPS gốc, ghi sự kiện cổ phiếu và tính trên cơ sở tham chiếu khi chuỗi sự kiện đã xác nhận | Có thêm 20% cổ phiếu miễn phí, DPS gốc giảm từ 1.000 xuống 900 đồng chưa đủ để nói khoản tiền của vị thế gốc giảm |

### 5.3. Đầu vào → xử lý → đầu ra

- **Đầu vào:** thông báo cổ tức, năm lợi nhuận, đợt thực hiện quyền, chuỗi sửa/hủy, độ đầy đủ và sự kiện cổ phiếu.
- **Xử lý:** xác định bản hiệu lực → ghép/tổng hợp → kiểm đủ dữ liệu → kiểm cơ sở cổ phiếu → trình bày lịch sử.
- **Đầu ra:** lịch cổ tức, mức công bố theo năm, DPS gốc/tham chiếu khi hợp lệ và lý do chưa so sánh được.

**Ví dụ về thay đổi số cổ phiếu:** người dùng có 100 cổ phiếu, mỗi cổ phiếu được công bố 1.000 đồng tiền mặt: khoản gộp là 100.000 đồng. Sau đó nhận thêm 20% cổ phiếu miễn phí, thành 120 cổ phiếu. Ở lần sau, mỗi cổ phiếu được 900 đồng. Nếu không giao dịch và cả 120 cổ phiếu đều đủ quyền lần sau, khoản gộp dự kiến là:

`120 × 900 = 108.000 đồng`.

DPS gốc giảm 10%, nhưng khoản tiền trong ví dụ tăng 8%. Chức năng phải giúp người dùng nhận ra khác biệt này. Đây là mô phỏng có giả định, chưa phải tiền thực nhận và chưa thay điều kiện so sánh tổng cổ tức cả năm.

**Vì sao vẫn cần dữ liệu cổ phiếu dù đề tài phân tích tiền mặt?** Cổ phiếu nhận thêm không được cộng như tiền mặt tại sự kiện, nhưng làm thay đổi cơ sở đọc DPS. Vì vậy phải giữ dữ liệu sự kiện phù hợp để tránh so sánh sai. Ngày chốt quyền không tự là ngày hiệu lực của mọi thay đổi; thiếu bằng chứng thì ghi chưa xác định. Quyền mua trả tiền hoặc sự kiện chưa hỗ trợ không được áp công thức như cổ phiếu miễn phí.

**Phạm vi yêu cầu:** nền FR19–FR24, FR28; G03 theo D05–D08. Theo dõi thực nhận của tài khoản/danh mục người dùng chưa thuộc chức năng lõi này.

## 6. BUC04 — Sàng lọc và đối chiếu ứng viên cổ tức

### 6.1. Mục đích và cách hiểu đơn giản

Giúp người dùng thu hẹp tập hồ sơ cần đọc, biết doanh nghiệp nào đáp ứng tiêu chí mình chọn và vì sao. Người dùng cũng thấy các trường hợp thiếu dữ liệu, thay vì hiểu nhầm rằng mọi hồ sơ không xuất hiện đều không phù hợp.

**Hiểu đơn giản:** một bảng kiểm có giải thích. Người dùng đặt câu hỏi, hệ thống kiểm từng hồ sơ và trả “đạt”, “không đạt” hoặc “chưa đủ cơ sở”. Đạt bảng kiểm chỉ nghĩa đáp ứng điều kiện đã chọn, chưa là kết luận nên đầu tư.

### 6.2. Hệ thống cần thực hiện những gì?

| Thành phần chức năng | Yêu cầu và kết quả người dùng nhận được | Ví dụ dễ hiểu |
|---|---|---|
| Chọn tập và điều kiện phân tích | Cho chọn doanh nghiệp, năm/phạm vi và các trường hợp cần tìm | Tìm các doanh nghiệp có LNST tăng nhưng CFO giảm trong hai năm liền nhau |
| Lưu bộ tiêu chí — **bổ sung G01** | Lưu tên, điều kiện, ngưỡng, kỳ và phiên bản để dùng lại; chỉ nhận chỉ tiêu/phép so sánh được hỗ trợ | Lưu bộ “Cần đọc về nguồn tiền cổ tức”, hôm sau mở lại đúng các điều kiện |
| Sàng lọc có giải thích — **bổ sung G01** | Trả trạng thái từng tiêu chí, số liệu, lý do và nguồn; phân biệt ba nhóm kết quả | A không đạt vì số dư âm; C chưa đủ cơ sở vì thiếu chi đầu tư |
| Đối chiếu hồ sơ trong cùng điều kiện | Cho xem số liệu/biểu đồ đã có với kỳ, phạm vi và đơn vị rõ; giữ các ô thiếu có lý do | Khi đọc A và B, người dùng đối chiếu tỷ số cùng năm, không so doanh nghiệp lớn/nhỏ chỉ bằng CFO tuyệt đối |

Việc bố trí bảng/biểu đồ so sánh nhiều doanh nghiệp song song là ý tưởng bổ sung cần chốt riêng, **được đề nghị ưu tiên sớm** sau nghiên cứu hướng nền tảng dữ liệu. Phân tích scatter/hệ số tương quan trong yêu cầu nền là khám phá mô tả, có số mẫu và giới hạn. So sánh giúp người dùng tìm khác biệt và đặt câu hỏi; chưa tạo ra bảng xếp hạng chất lượng đầu tư.

### 6.3. Đầu vào → xử lý → đầu ra

- **Đầu vào:** tập doanh nghiệp, bản dữ liệu chốt và tiêu chí người dùng chọn.
- **Xử lý:** kiểm dữ liệu đủ/tương thích → đánh giá từng điều kiện → tổng hợp trạng thái → trình bày lý do.
- **Đầu ra:** danh sách theo ba nhóm, giải thích từng điều kiện, thông tin cần bổ sung và hồ sơ người dùng chọn đọc tiếp.

**Ví dụ:** người dùng thử tiêu chí “CFO sau chi đầu tư và phân phối không âm”. Đây là tiêu chí minh họa do người dùng đặt, không phải chuẩn an toàn chung.

| Công ty | CFO (tỷ đồng) | Chi đầu tư (tỷ đồng) | Phân phối thực chi (tỷ đồng) | Kết quả |
|---|---:|---:|---:|---|
| A | 120 | 80 | 60 | −20: không đạt tiêu chí |
| B | 95 | 20 | 40 | 35: đạt tiêu chí |
| C | 110 | Chưa có | 30 | Chưa đủ cơ sở |

Nếu thêm nhiều điều kiện đồng thời: có một điều kiện không đạt thì kết quả chung không đạt; nhưng mọi điều kiện thiếu vẫn được hiển thị. Nếu chưa có điều kiện không đạt nhưng còn điều kiện chưa rõ thì kết quả chung chưa đủ cơ sở. Chỉ khi tất cả điều kiện đạt mới vào nhóm đạt.

**Kết quả giúp quyết định gì?** Chọn B để đọc tiếp theo tiêu chí đã đặt; chọn A để tra soát khoản chi; bổ sung dữ liệu cho C. Không tự suy B là khoản đầu tư tốt hơn A chỉ từ ví dụ này.

**Phạm vi yêu cầu:** nền FR29–FR30, FR32; lưu tiêu chí và ba trạng thái theo D09–D10. Chưa có điểm chất lượng tổng hợp hoặc khuyến nghị mua/bán.

## 7. BUC05 — Quản lý hồ sơ thẩm định cổ tức

### 7.1. Mục đích và cách hiểu đơn giản

Giúp người dùng biến các bảng số liệu thành hồ sơ nhận xét có bằng chứng: đã biết gì, chưa biết gì, cần kiểm tra tiếp gì và nhận xét được lập trên bản dữ liệu nào. Khi nguồn thay đổi, người dùng vẫn mở lại được cơ sở của nhận xét trước đây.

**Hiểu đơn giản:** một cuốn sổ nghiên cứu gắn với số liệu và tài liệu nguồn. Mỗi nhận xét có căn cứ, mỗi câu hỏi có trạng thái xử lý, và bản cũ được giữ lại để kiểm tra về sau.

### 7.2. Hệ thống cần thực hiện những gì?

| Thành phần chức năng | Yêu cầu và kết quả người dùng nhận được | Ví dụ dễ hiểu |
|---|---|---|
| Lập hồ sơ từ kết quả phân tích — **bổ sung G01** | Lưu doanh nghiệp, kỳ, mốc dữ liệu, bộ tiêu chí và kết quả tương ứng | Lập hồ sơ A từ số dư −20 tỷ và bảng giải thích đã xem |
| Ghi nhận nhận xét và công việc tra soát — **bổ sung G01** | Cho ghi nhận xét/câu hỏi, người ghi, thời gian, nguồn và trạng thái chưa xử lý/đã xử lý; tách ghi chú khỏi số liệu nguồn | Ghi “Cần xem khoản chi đầu tư tăng vì dự án nào”; thêm bằng chứng khi đọc được thuyết minh |
| Truy vết bằng chứng | Cho đi từ kết quả tới công thức, các số đầu vào và vị trí trong tài liệu | Từ −20 tỷ truy tới CFO 120, chi đầu tư 80 và khoản trả 60 tỷ trên nguồn |
| Lưu, xuất và tái tính hồ sơ | Giữ bản dữ liệu/công thức/tiêu chí của hồ sơ; xuất để đọc lại và tái tính khi phiên bản được hỗ trợ | Sau khi BCTC sửa, vẫn mở lại hồ sơ cũ để biết nhận xét trước dựa trên số nào |

### 7.3. Đầu vào → xử lý → đầu ra

- **Đầu vào:** kết quả phân tích/sàng lọc, nguồn, ghi chú và câu hỏi của người dùng.
- **Xử lý:** tạo hồ sơ → gắn bằng chứng → ghi nhận vấn đề → lưu bản chốt → xuất/tái tính.
- **Đầu ra:** hồ sơ thẩm định có thể đọc, kiểm tra và sử dụng lại.

**Ví dụ một hồ sơ đơn giản của A:**

| Mục | Nội dung |
|---|---|
| Nhận xét từ số liệu | CFO kỳ này chưa bao phủ chi đầu tư và phân phối được chọn; số dư −20 tỷ |
| Bằng chứng | Ba số đầu vào, công thức và trang tài liệu nguồn |
| Giả thuyết người dùng | Có thể liên quan nhu cầu tiền cho một dự án; chưa được xác minh |
| Việc cần tra soát | Đọc thuyết minh đầu tư và tình hình tiền tích lũy; kiểm khoản phân phối thuộc chủ thể nào |
| Trạng thái | Còn câu hỏi chưa xử lý |

Nếu BCTC được sửa từ CFO 120 thành 125 tỷ, hồ sơ cũ vẫn giữ −20 tỷ theo dữ liệu cũ. Khi người dùng lập bản phân tích mới với các khoản khác giữ nguyên, kết quả là −15 tỷ; hai bản phân biệt rõ. Tự động thông báo mọi luận điểm bị ảnh hưởng là ý tưởng giai đoạn sau, chưa phải chức năng đã hoàn thành.

**Phạm vi yêu cầu:** nền FR31, FR34–FR35; hồ sơ/ghi chú/công việc và xuất hồ sơ mở rộng theo D11–D12. Không quản lý lệnh giao dịch hoặc tài khoản chứng khoán.

## 8. Ví dụ sử dụng xuyên suốt năm chức năng

1. **Quản lý hồ sơ dữ liệu:** người dùng chọn A, B, C trong giai đoạn theo dõi; hệ thống thu tài liệu, người vận hành kiểm/duyệt. Hồ sơ C còn thiếu chi đầu tư.
2. **Đánh giá tiền mặt:** ở kỳ đang xét, A còn −20 tỷ sau hai khoản chi, B còn 35 tỷ; C chưa tính được kết quả này.
3. **Tra soát lịch sử cổ tức:** kiểm đợt cổ tức thuộc năm lợi nhuận nào, bản nào còn hiệu lực và có thay đổi cơ sở cổ phiếu hay không. Năm thiếu thông báo không được tự kết luận cổ tức giảm.
4. **Sàng lọc:** theo tiêu chí số dư không âm, B đạt, A không đạt, C chưa đủ cơ sở. Người dùng xem lý do và tự chọn hồ sơ cần đọc tiếp.
5. **Quản lý hồ sơ thẩm định:** lưu nhận xét về A, bằng chứng và câu hỏi chưa giải quyết; lưu bản phân tích B; tạo việc bổ sung dữ liệu cho C.

Tác vụ xuyên suốt ngách cổ tức là **chọn doanh nghiệp cần đọc và lập nhận xét có bằng chứng**, cùng các bước còn phải xác minh. Ngoài tác vụ này, nền tảng còn cần phục vụ tra cứu/xuất bộ dữ liệu, xem xu hướng và khám phá quan hệ đã có yêu cầu ở mục 2.1. Các tương tác/so sánh đề xuất ở mục 2.2 mở rộng cách sử dụng phần phân tích, chưa tự là phạm vi đã chốt.

## 9. Phần đã có minh chứng và phần còn cần thực hiện

| Nội dung | Trạng thái hiện tại |
|---|---|
| Đặc tả năm UC lớn và yêu cầu chức năng | Đã có tài liệu, chưa ghi nhận phê duyệt giảng viên |
| Thu nguồn và đọc tài liệu | Có prototype nghiên cứu; chưa hoàn thiện mọi luồng dữ liệu của ứng dụng |
| Phép tính G02/G03 và quy tắc ba trạng thái | Prototype độc lập đã vượt qua 20 kiểm tra; có đối chiếu nguồn DHG và quyền cổ phiếu FPT trong nghiên cứu |
| Giao diện, dữ liệu được duyệt và workflow hồ sơ hoàn chỉnh | Cần triển khai và kiểm thử đầu cuối |
| Biểu đồ/xu hướng/scatter/bộ lọc | Đã có yêu cầu trong SRS; chưa có giao diện phân tích hoàn chỉnh đã chạy |
| Khám phá dữ liệu, so sánh song song, tương tác liên kết, lưu góc nhìn và theo dõi thay đổi | Đã nghiên cứu và đề xuất ở mục 2.2; phần bổ sung cần đặc tả trước triển khai |
| Ích lợi với người dùng | Cần đo thời gian thẩm định, lỗi diễn giải và khả năng nhận diện vấn đề; chưa chứng minh cải thiện lợi nhuận đầu tư |

Các chức năng về lịch thu nhập theo vị thế, đối soát tiền thực nhận, dữ liệu giá/lợi suất, dự báo và phát hiện ảnh hưởng tự động là ý tưởng nghiên cứu tiếp; chưa thêm thành nghĩa vụ trong tài liệu này.

## 10. Tài liệu đối chiếu

- [SRS v3.2](22-srs-dac-ta-yeu-cau-phan-mem.md): yêu cầu chi tiết, mã FR/E/D, điều kiện và tình huống kiểm chứng.
- [Cấu trúc UC lớn và phân rã](../research-dividend-functions/01-uc-lon-va-phan-ra.md): cách chuyển từ chức năng lớn thành các việc triển khai.
- [Bộ nghiên cứu ba chức năng](../research-dividend-functions/README.md): nghiệp vụ, thiết kế, tính khả thi, công sức và nguồn nghiên cứu.
- [Minh chứng và protocol](../research-dividend-functions/07-minh-chung-va-protocol.md): phân biệt prototype đã chạy với kiểm thử ứng dụng chưa thực hiện.
- [Hướng nền tảng dữ liệu và năng lực phân tích](../research-financial-platform-direction/README.md): kết luận nghiên cứu GitHub/tài liệu và thứ tự phát triển đề xuất.

Tài liệu này giải thích yêu cầu hiện hành và ghi riêng các ý tưởng phát triển; không tạo thêm nghĩa vụ hoặc thay đổi phạm vi SRS.
