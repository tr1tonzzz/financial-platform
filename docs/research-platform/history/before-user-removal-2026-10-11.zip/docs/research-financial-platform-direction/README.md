# Hướng nền tảng dữ liệu tài chính và các chức năng phân tích cần có

Ngày nghiên cứu: **11/10/2026**. Đây là kết quả nghiên cứu và đề xuất sản phẩm; chưa phải phần mềm đã triển khai hoặc phạm vi SRS mới đã chốt.

## 1. Có đang lệch sang hệ thống quản lý báo cáo tài chính không?

**Có nguy cơ lệch trong cách tổ chức chức năng và trải nghiệm sử dụng.** Thu thập, kiểm tra và quản lý báo cáo là phần cần thiết, nhưng nếu người dùng chủ yếu tải PDF, duyệt số rồi nhận vài tỷ số thì đầu ra của hệ thống vẫn thiên về xử lý hồ sơ. Cách giải thích trước đây đã làm phần này nổi bật quá mức.

Hướng nền tảng dữ liệu vẫn có trong thiết kế: số liệu được chuẩn hóa theo doanh nghiệp/kỳ/phạm vi, có phiên bản, nguồn, khả năng truy vấn và xuất để dùng lại. Cần đưa việc **khai thác dữ liệu để phân tích** thành trải nghiệm chính. Đây là nhận xét về thiết kế hiện tại; repository chưa có ứng dụng hoàn chỉnh để đánh giá trải nghiệm thực tế.

| Người dùng muốn làm | Nền tảng cần cung cấp |
|---|---|
| Lấy số liệu của nhiều công ty, nhiều năm mà không đọc lại từng PDF | Bộ dữ liệu có thể chọn, lọc, tra cứu và xuất; chỉ tiêu có định nghĩa và nguồn |
| Biết tình hình tài chính đang thay đổi thế nào | Biểu đồ xu hướng, bảng biến động và các góc nhìn cùng dùng một bộ lọc |
| Biết doanh nghiệp khác nhau ở đâu | So sánh theo cùng kỳ, phạm vi, đơn vị và tỷ số phù hợp |
| Tìm chỗ cần đọc kỹ | Bộ lọc trường hợp, biểu đồ quan hệ và đường đi đến số liệu chi tiết |
| Đánh giá một câu hỏi về cổ tức | Kết hợp dòng tiền, khoản chi, lịch sử cổ tức và sự kiện cổ phiếu |
| Theo dõi lại một nhận xét sau khi dữ liệu thay đổi | Lưu lần phân tích, mở lại và đối chiếu bản cập nhật |

**Hướng sản phẩm đề xuất:** nền tảng dữ liệu tài chính doanh nghiệp Việt Nam, trước mắt tập trung vào phân tích lợi nhuận, dòng tiền và cổ tức. Dữ liệu đã kiểm tra là tài sản của nền tảng; BCTC và thông báo là bằng chứng; phân tích cổ tức là một ứng dụng cụ thể trên nền dữ liệu ấy.

Năm BUC hiện hành vẫn có giá trị. Cần làm rõ năng lực phân tích bên trong và giữa các BUC, không chỉ đổi tên chúng.

## 2. Hệ thống có hỗ trợ biểu đồ không?

**Có trong yêu cầu, chưa có giao diện hoàn chỉnh đã chạy.** SRS v3.2 đã có xu hướng LNST/CFO, cơ cấu tiền/nợ phải trả, lịch cổ tức, scatter, bộ lọc trường hợp và dashboard ở FR25–FR32. Tài liệu giải thích trước chưa nêu rõ người dùng thao tác trên các góc nhìn này như thế nào.

Phần thiếu cần cụ thể hóa là: chọn số liệu muốn xem; đổi doanh nghiệp/giai đoạn và cập nhật đồng bộ; đặt hai doanh nghiệp cạnh nhau; chọn điểm trên biểu đồ để xem chi tiết; chuyển giữa bảng và biểu đồ; lưu và mở lại cùng điều kiện phân tích.

Tài liệu nghề nghiệp của CFA Institute xác định phân tích cần so sánh theo thời gian và giữa doanh nghiệp, diễn giải kết quả, rồi theo dõi lại. Tính tỷ số chỉ là một bước. [CFA Institute — Financial Analysis Techniques](https://www.cfainstitute.org/insights/professional-learning/refresher-readings/2026/financial-analysis-techniques).

## 3. Tám chức năng nên ưu tiên, giải thích bằng việc người dùng làm được

Các ví dụ A/B dưới đây là giả định.

| Mã | Chức năng | Giải quyết việc gì? | Ví dụ dễ hiểu |
|---|---|---|---|
| A01 | **Khám phá và lấy dữ liệu tài chính** | Tìm đúng bộ số liệu cần dùng, biết dữ liệu còn thiếu ở đâu | Chọn A/B, 2023–2025, LNST và CFO; nhận bảng sáu kỳ kèm nguồn và xuất dữ liệu đang chọn |
| A02 | **Theo dõi tình hình tài chính bằng biểu đồ** | Nhìn ra xu hướng và năm thay đổi đáng chú ý | LNST A tăng 90→100 tỷ nhưng CFO giảm 130→80 tỷ; chọn điểm 2025 để xem số liệu và nguồn |
| A03 | **So sánh doanh nghiệp** | Biết khác biệt trên một cơ sở rõ ràng để chọn câu hỏi cần đọc tiếp | A có CFO lớn hơn B, nhưng CFO/LNST của A là 0,8 còn B là 1,2; xem cùng năm thay vì chỉ so số tiền |
| A04 | **Tìm và khám phá trường hợp cần chú ý** | Rút ngắn việc tìm hồ sơ có đặc điểm mình quan tâm | Lọc “lợi nhuận tăng nhưng CFO giảm”, xem doanh nghiệp xuất hiện ở đâu trên biểu đồ quan hệ và mở chi tiết |
| A05 | **Phân tích các khoản tạo ra chênh lệch tiền** | Biết khoản nào đóng góp vào chênh lệch giữa lợi nhuận, dòng tiền và tiền sau các khoản chi | Xem cầu nối lợi nhuận trước thuế→CFO; sau đó CFO 120−chi đầu tư 80−phân phối 60=−20 tỷ |
| A06 | **Phân tích lịch sử cổ tức và sự kiện liên quan** | Đọc đúng cổ tức qua các năm và cơ sở cổ phiếu | Đợt trả tháng 6/2026 thuộc lợi nhuận 2025; sự kiện tăng cổ phiếu giúp giải thích vì sao DPS gốc chưa thể so trực tiếp |
| A07 | **Theo dõi doanh nghiệp và thay đổi dữ liệu** | Biết điều gì mới làm mình cần đọc lại nhận xét trước | Sau khi bản CFO 120 được thay bằng bản đã duyệt 125, hệ thống cho xem trước/sau và các phép tính liên quan |
| A08 | **Lưu và tiếp tục một lần phân tích** | Tiếp tục công việc mà không chọn lại bảng, biểu đồ và điều kiện từ đầu | Lưu A/B, 2023–2025, bộ lọc và ghi chú; mở lại đúng bản đã lưu hoặc chủ động chuyển sang dữ liệu mới |

A01–A04 làm rõ bản sắc nền tảng dữ liệu và phân tích. A05–A06 làm sâu ngách lợi nhuận–dòng tiền–cổ tức. A07–A08 giúp việc phân tích được sử dụng nhiều lần. Ba đề xuất trước **G02/G03/G01** lần lượt đóng góp cho A05, A06 và A04/A08; được kế thừa.

Không phải cả tám chức năng đều mới: có phần đã nằm trong SRS, có phần cần bổ sung tương tác hoặc dữ liệu. [Đối chiếu và tính khả thi từng chức năng](02-chuc-nang-phan-tich-va-kha-thi.md).

## 4. Nghiên cứu đã tìm thấy gì?

Đợt này bổ sung **năm repository** và đọc sâu lại FinanceToolkit. Đã lưu **32 tệp nguồn/README/license**, sáu inventory, commit cố định và mã kiểm tra toàn vẹn. Chỉ đọc mã và tài liệu; chưa cài/chạy các ứng dụng nguồn. Tính cả hai đợt trước là 17 repository khác nhau, không phải 17 hệ thống hoàn chỉnh đã nghiệm thu.

| Dự án/tài liệu | Ý tưởng áp dụng được | Điều phải điều chỉnh khi dùng ở Việt Nam |
|---|---|---|
| [EdgarTools](https://github.com/dgunning/edgartools) | Truy vấn chỉ tiêu/kỳ, bảng nhiều kỳ, kiểm mốc dữ liệu | Học mô hình dữ liệu; bộ đọc SEC/XBRL không thay được bộ xử lý BCTC Việt Nam |
| [FinanceDatabase](https://github.com/JerBouma/FinanceDatabase) | Danh mục doanh nghiệp có thể tìm/lọc để chọn tập phân tích | Phải xây danh mục Việt Nam có nguồn; đây không phải kho BCTC Việt Nam sẵn dùng |
| [FinanceToolkit](https://github.com/JerBouma/FinanceToolkit) | Dùng một bộ dữ liệu cho bảng nhiều doanh nghiệp/kỳ và phép tính minh bạch | Chọn công thức phù hợp, kiểm đầu vào; không cần đưa hàng trăm tỷ số vào MVP |
| [finagg](https://github.com/theOGognf/finagg) | Dữ liệu thô→dữ liệu chuẩn; so sánh doanh nghiệp với nhóm ngành | Cần tập cùng ngành đủ phù hợp; không lấy ba công ty khác ngành làm chuẩn ngành |
| [FinceptTerminal](https://github.com/Fincept-Corporation/FinceptTerminal) | Góc nhìn xu hướng tài chính, bảng đối chiếu doanh nghiệp và danh sách theo dõi | Giữ phần phân tích BCTC; nhiều mô-đun giao dịch/giá của dự án vượt dữ liệu hiện có |
| [OpenBB backend mẫu](https://github.com/OpenBB-finance/backends-for-openbb) và [tài liệu Workspace](https://docs.openbb.co/workspace/analysts/widgets/interacting-with-data) | Các bảng/biểu đồ chia sẻ bộ lọc, xem dữ liệu dưới biểu đồ | Backend có ví dụ dùng dữ liệu giả lập; Workspace là sản phẩm riêng, không coi mọi tính năng giao diện là mã mở |

Kết luận lựa chọn chức năng là **suy luận thiết kế của nghiên cứu này**, không phải bằng chứng các dự án trên giúp tăng lợi nhuận đầu tư. [Minh chứng mã và tài liệu](01-bang-chung-va-bai-hoc.md), [sổ nguồn](sources.md).

## 5. Hướng thực hiện để tránh UC lớn nhưng chức năng nhỏ

Ưu tiên một tác vụ hoàn chỉnh: **chọn A/B trong ba năm → xem xu hướng → so sánh → lọc trường hợp → chọn số liệu cần tra soát → lưu lần phân tích**. Hoàn thành tác vụ này có giá trị hơn một màn hình chỉ hiển thị tỷ số hoặc nhiều biểu đồ đứng riêng lẻ.

1. **Đợt đầu:** A01/A02/A03/A04 với sáu trường lõi, bộ lọc chung và truy nguồn. Làm các biểu đồ đã có yêu cầu; đề xuất bổ sung bảng so sánh và tương tác cần thiết.
2. **Đợt tiếp:** tích hợp cầu nối/G02, lịch sử/G03 và lưu phân tích/G01. A08 dùng bố cục cố định trước; chưa cần một trình thiết kế dashboard phức tạp.
3. **Sau khi các tác vụ trên dùng được:** A07 theo dõi thay đổi. Thử kịch bản giả định và bổ sung nhóm số liệu khi có câu hỏi người dùng cần giải quyết.

Sáu trường hiện có đủ cho một số tác vụ hữu ích, **chưa đủ cho phân tích tài chính toàn diện**. Biên lợi nhuận cần doanh thu; thanh khoản ngắn hạn cần tài sản/nợ ngắn hạn; phân tích vốn lưu động cần các dòng liên quan. Mở rộng dữ liệu theo câu hỏi này, không theo số lượng chỉ tiêu một dự án khác quảng bá.

Thứ tự trên là đề xuất sau nghiên cứu; chưa sửa phạm vi SRS v3.2 hoặc ngân sách 167 giờ/64–98 giờ trước đây. Cần lập dự toán cho lát cắt được chọn trước khi đưa các phần mới vào kế hoạch chính thức.

## 6. Tài liệu đọc tiếp

- [Từng chức năng: mục đích, ví dụ, dữ liệu, tính khả thi và tác vụ kiểm chứng](02-chuc-nang-phan-tich-va-kha-thi.md).
- [Bằng chứng GitHub và cơ sở phân tích/thiết kế tương tác](01-bang-chung-va-bai-hoc.md).
- [Yêu cầu chức năng giải thích đơn giản — đã cập nhật phần phân tích](../research-platform/27-yeu-cau-chuc-nang-va-vi-du.md).
- [SRS v3.2 hiện hành](../research-platform/22-srs-dac-ta-yeu-cau-phan-mem.md).
