# Định hướng hiện hành của nền tảng tài chính

Ngày chốt đề xuất: **03/10/2026**, sau khi mở rộng lại phạm vi theo yêu cầu của người thực hiện. Nền tảng tài chính là lĩnh vực gốc; BCTC–cổ tức chỉ là một hướng đã khảo sát.

**Đề tài đề xuất chọn:** Nền tảng phân tích sức khỏe tài chính doanh nghiệp Việt Nam từ BCTC với dữ liệu có truy vết và kiểm định chất lượng.

Hệ thống hỗ trợ thu thập/nhập BCTC, trích và chuẩn hóa số, duyệt lỗi, phân tích lợi nhuận–dòng tiền–cấu trúc tài chính, so sánh cùng cơ sở và mở bằng chứng cho từng kết quả. Cổ tức, giá chứng khoán và hỏi đáp AI không là nghĩa vụ MVP. Tên đăng ký và rubric nghiệm thu cần thầy xác nhận; đây là bản chốt đề xuất để triển khai/trao đổi, chưa có phê duyệt của giảng viên.

Bổ sung nghiên cứu cùng ngày: [tự crawl BCTC gần hiện tại](../research-crawl-methods/README.md). Tự phát hiện từ danh mục IR và cập nhật file là năng lực lõi đề xuất; đã có prototype tải 8 PDF năm 2025/bán niên 2026 của HPG, DHG, VHC, HPA và kiểm tra lại bằng HTTP 304. Đây chưa là ứng dụng hoàn chỉnh hoặc dataset chín trường; bốn PDF qua host có robots chưa xác định được ghi rõ là thử hữu hạn. Phạm vi lịch sử và quỹ học/làm không tăng vì thêm điểm sáng này.

## Đọc theo thứ tự

1. [So sánh bảy hướng và cơ sở lựa chọn](01-so-sanh-va-quyet-dinh.md).
2. [SRS và lý do phù hợp đồ án IT](02-de-tai-va-srs.md).
3. [Thiết kế hệ thống](03-kien-truc-va-du-lieu.md).
4. [Kế hoạch học và làm 13 tuần](04-ke-hoach-13-tuan.md).
5. [Kiến thức nền và bài tập theo project](05-lo-trinh-hoc.md).
6. [Thí nghiệm và kiểm thử](06-danh-gia-va-nghiem-thu.md).
7. [Báo cáo hằng tuần và quy trình phản hồi](07-bao-cao-hang-tuan.md).
8. [Chuẩn bị bảo vệ và sử dụng AI](08-chuan-bi-bao-ve.md).
9. [Phát triển lên đồ án tốt nghiệp](09-lien-thong-tot-nghiep.md).
10. [Sổ tài liệu nghiên cứu và nguồn học](10-so-nguon.md).

## Hồ sơ từng ý tưởng

| Hướng | Đề xuất | Tài chính | IT |
|---|---|---|---|
| A1 Sức khỏe doanh nghiệp | [Khả thi](ideas/a1-suc-khoe-doanh-nghiep/01-y-tuong-va-kha-thi.md) | [Kiến thức](ideas/a1-suc-khoe-doanh-nghiep/02-kien-thuc-tai-chinh.md) | [Kỹ thuật](ideas/a1-suc-khoe-doanh-nghiep/03-ky-thuat-it.md) |
| A2 BCTC–cổ tức | [Khả thi](ideas/a2-bctc-co-tuc/01-y-tuong-va-kha-thi.md) | [Kiến thức](ideas/a2-bctc-co-tuc/02-kien-thuc-tai-chinh.md) | [Kỹ thuật](ideas/a2-bctc-co-tuc/03-ky-thuat-it.md) |
| A3 Rủi ro danh mục | [Khả thi](ideas/a3-rui-ro-danh-muc/01-y-tuong-va-kha-thi.md) | [Kiến thức](ideas/a3-rui-ro-danh-muc/02-kien-thuc-tai-chinh.md) | [Kỹ thuật](ideas/a3-rui-ro-danh-muc/03-ky-thuat-it.md) |
| A4 Tài chính cá nhân | [Khả thi](ideas/a4-tai-chinh-ca-nhan/01-y-tuong-va-kha-thi.md) | [Kiến thức](ideas/a4-tai-chinh-ca-nhan/02-kien-thuc-tai-chinh.md) | [Kỹ thuật](ideas/a4-tai-chinh-ca-nhan/03-ky-thuat-it.md) |
| A5 Dòng tiền SME | [Khả thi](ideas/a5-dong-tien-doanh-nghiep-nho/01-y-tuong-va-kha-thi.md) | [Kiến thức](ideas/a5-dong-tien-doanh-nghiep-nho/02-kien-thuc-tai-chinh.md) | [Kỹ thuật](ideas/a5-dong-tien-doanh-nghiep-nho/03-ky-thuat-it.md) |
| A6 Hỏi đáp tài liệu | [Khả thi](ideas/a6-hoi-dap-tai-lieu/01-y-tuong-va-kha-thi.md) | [Kiến thức](ideas/a6-hoi-dap-tai-lieu/02-kien-thuc-tai-chinh.md) | [Kỹ thuật](ideas/a6-hoi-dap-tai-lieu/03-ky-thuat-it.md) |
| A7 Vĩ mô | [Khả thi](ideas/a7-du-lieu-vi-mo/01-y-tuong-va-kha-thi.md) | [Kiến thức](ideas/a7-du-lieu-vi-mo/02-kien-thuc-tai-chinh.md) | [Kỹ thuật](ideas/a7-du-lieu-vi-mo/03-ky-thuat-it.md) |

## Trạng thái thật và phạm vi thay đổi

Repo hiện có tài liệu, script khảo sát và raw evidence; chưa thấy mã ứng dụng trong `src` tại lần đọc này. Đã có bằng chứng tải BCTC và chạy OCR, chưa có dataset chín trường trên toàn mẫu, dashboard hoặc kết quả benchmark độc lập. Kế hoạch học và làm dưới đây là công việc tương lai.

Bộ này thay vai trò định hướng chung của các tài liệu chốt BCTC–cổ tức trước đây. Các bộ `research-development`, `research-options`, `research-design` và đặc tả cổ tức trong `initial-docs` được giữ làm nghiên cứu nhánh A2/lịch sử, không dùng đồng thời như yêu cầu MVP mới. Không tự đổi ngày hay viết rằng công việc cũ chưa làm là đã hoàn thành.

Mốc kế hoạch đang **giả định** 13 tuần, 10–12 giờ/tuần, một người thực hiện. Tuần 1 tính từ khi bắt đầu kế hoạch này; chưa gắn lịch học kỳ hoặc đặt lịch gửi tự động. Không tự gửi tài liệu cho giảng viên.
