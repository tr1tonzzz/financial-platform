# Báo cáo tiến độ hằng tuần

Mỗi tuần một bộ Word 2–4 trang và 5–6 slide, cùng link/artifact demo. Lịch gặp thầy do người thực hiện xác định; không có automation hoặc gửi tin được tạo trong lượt nghiên cứu này.

## 1. Word và slide có vai trò khác nhau

Word giữ chi tiết để thầy theo dõi quyết định, số đo, lỗi và kế hoạch. Slide chỉ trình điều quan trọng và giúp giải thích/demo. Không copy nguyên Word lên slide. Cả hai dùng cùng số đếm, scope và trạng thái. Chưa chạy thì ghi kế hoạch, chưa đối chiếu thì ghi ứng viên, chưa hiểu thì ghi nội dung cần học.

## 2. Khung Word dùng mỗi tuần

1. Tên đề tài, tuần/khoảng ngày, người thực hiện và mục tiêu tuần.
2. Kết quả: task dự kiến/thực đạt, artifact path/commit/run, số đếm có mẫu số. Ba trạng thái hoàn thành, đang làm, chưa làm.
3. Một vấn đề kỹ thuật: đầu vào, cách xử lý, lựa chọn khác, lỗi gặp và lý do chọn giải pháp. Đính một sơ đồ/bảng có ích thay vì trang ảnh chụp code dài.
4. Kiến thức tài chính/Python đã học: một ví dụ tự tính/viết, test và câu giải thích của chính người làm. Phần AI hỗ trợ và phần đã tự kiểm tra.
5. Hạn chế/rủi ro: nguyên nhân, ảnh hưởng tiến độ và việc xử lý. Không chỉ ghi “chưa có thời gian”.
6. Tuần sau: tối đa ba đầu ra đo được, giờ dự kiến, tiêu chí xong; câu hỏi cụ thể cho thầy.
7. Phản hồi sau buổi gặp: yêu cầu, quyết định scope và thay đổi task. Điền sau khi thật sự nhận phản hồi, không giả lập ý thầy.

Ví dụ đúng: “B1 tìm được 7/9 trường trên file X; hai trường missing; chưa kiểm tra độc lập.” Không viết “OCR đạt độ chính xác cao” chỉ từ một ảnh đẹp.

## 3. Khung 6 slide và cách nói

| Slide | Nội dung | Cách trình bày |
|---|---|---|
| 1 | Mục tiêu và kết quả chính tuần | 30–45 giây, nói cụ thể điều mới chạy được |
| 2 | Tiến độ so kế hoạch | Task/artifact/số đếm; tránh % tiến độ tự đặt |
| 3 | Một phần kỹ thuật | Luồng input–xử lý–output, code ngắn hoặc schema cần giải thích |
| 4 | Demo/kiểm thử | Mở app/log thật, một thành công và một lỗi được xử lý |
| 5 | Điều hiểu và hạn chế | Ví dụ tài chính/Python, giải pháp khác và lý do |
| 6 | Tuần sau và điểm trao đổi | Ba đầu ra, scope risk và câu hỏi cần thầy góp ý |

Thời lượng gợi ý 5–8 phút cộng demo/câu hỏi. Speaker notes chứa script ngắn và nguồn; không đọc toàn văn. Buổi đầu có thể dùng Word/slide đề xuất đã tạo để trình so sánh hướng, dữ liệu và kế hoạch. Đó là báo cáo nghiên cứu đề xuất, không phải bằng chứng bạn đã học xong tuần 1.

## 4. Thói quen bảo đảm chất lượng

Trước gặp: chạy demo từ trạng thái mới, đồng bộ số giữa Word/slide/log, thử nói không nhìn notes, chuẩn bị ảnh/log fallback đúng snapshot. Sau gặp: ghi decision log và backlog. Đổi tên đề tài/scope phải cập nhật bản chốt, không để SRS một hướng và slide một hướng khác.

Gợi ý đặt file khi thật có báo cáo: `reports/tuan-01/bao-cao.docx`, `reports/tuan-01/tien-do.pptx`, `notes.md`, link run. Không tạo 13 bộ với tiến độ tưởng tượng. Mẫu Markdown tuần: `mau-bao-cao-tuan.md` trong thư mục này.
