# Protocol đánh giá và kiểm thử

Thiết kế ngày 03/10/2026, chưa có kết quả nghiệm thu. Câu hỏi chính là dữ liệu đúng hơn/đỡ tốn công thế nào, ứng dụng có chạy và truy vết được không.

## 1. Bộ phát triển và holdout

Tài liệu dùng viết parser và số OCR 11/12 trước đây thuộc development. Chọn các PDF khác để holdout, ưu tiên cùng phạm vi kế toán nhưng khác layout và có cả text/scan. Với target 30 báo cáo, gợi ý 6–10 development và khoảng 10 holdout ×9 targets = khoảng 90 ô; còn lại dùng kiểm tra vận hành. Đó là gợi ý cỡ mẫu, không bảo đảm lực thống kê. Nếu scope còn 15 báo cáo, điều chỉnh và công bố mẫu nhỏ.

Đóng băng danh sách/kỳ/scope/locator gold trước test; không sửa parser theo đáp án rồi vẫn gọi là kết quả holdout. Gold cần người khác kiểm tra theo rubric nếu có thể; nếu người thực hiện tự chấm, báo tự chấm và giới hạn, không gắn nhãn độc lập. Không tự gửi yêu cầu chấm cho ai trong lượt này.

## 2. Baseline và metric

| Phương án | Nội dung | Số đo cần ghi |
|---|---|---|
| B0 | Text-only + regex nhãn | Đúng joint/target kỳ vọng, missing và runtime |
| B1 | B0 + OCR fallback + parser cột | Cùng mẫu số; sai chữ số, dấu, unit, kỳ, scope |
| B2 | B1 + validator + người duyệt | Đúng sau sửa và phút review; không coi sửa tay là độ đúng tự động |

Joint correctness yêu cầu metric/value/unit/period/scope cùng đúng trong tolerance số đã định nghĩa. Accuracy = target đúng / target kỳ vọng; missing tính không đúng. Coverage = target thu được / target kỳ vọng, phân biệt candidate và reviewed. Báo thêm precision nếu có extra candidate sai, success per document và error breakdown. Số VND nguyên cần exact match; nếu nguồn làm tròn thì định nghĩa tolerance trước và giữ đơn vị. Report tỷ lệ cùng số đếm, cỡ mẫu và khoảng tin cậy thích hợp, không báo 95% trần trụi trên vài ô.

Đo wall-clock tải/trích/OCR/normalize/review riêng, median/P90 với máy và cấu hình. So B1 với thao tác đọc/nhập tay trên cùng target nếu muốn nói tiết kiệm thời gian; counterbalance thứ tự hoặc nêu giới hạn người đã nhớ số. Không dùng 29,8 giây OCR cho 10 ảnh lựa chọn làm thời gian end-to-end.

## 3. Kiểm thử chức năng và nghiệp vụ

- Normalize: `1.234.567`, `(1.234.567)`, đơn vị triệu, ô trống và dấu gạch với ngữ cảnh.
- Period/scope: số riêng quý và YTD; hợp nhất và riêng; cột hiện tại và kỳ so sánh.
- Ratios: mẫu số thiếu/0/âm, operands khác kỳ, LNST tổng/parent không tương thích.
- Store: nhập lại không trùng, sửa có audit, rollback nếu lỗi giữa ghi fact và review, giữ bản mới khác hash.
- Collector: timeout/404/HTML thay PDF, resume và skip policy; không cần tấn công hay crawl tải lớn để thử.
- End-to-end: một file thật qua candidates → duyệt → metric → UI/export; truy locator ngược lại, một failure được hiển thị rõ.

## 4. Case study và nghiệm thu

Ba case có bảng dữ liệu, phép tính, nguồn và nhận xét có giới hạn: lợi nhuận–CFO lệch; cấu trúc nợ/tài sản thay đổi; hai doanh nghiệp cùng cơ sở/nhóm tham chiếu có khác biệt. Case là phân tích mô tả, không có nhãn rủi ro do suy đoán để huấn luyện ML.

Nghiệm thu project: scope đã chốt và coverage ledger, pipeline/UI thật, test/benchmark, ba case, raw/manifest cách tái lập, ERD/architecture, report/slide và demo lỗi. Người thực hiện giải thích được code/công thức và sửa một trường hợp nhỏ trực tiếp. Không yêu cầu mô hình AI để được coi là IT; nếu rubric bắt buộc AI/ML phải đối chiếu tuần 1 và chỉnh protocol cụ thể, không thêm chatbot cho có.

## 5. Đánh giá năng lực tự crawl và cập nhật

Freeze expected issuer–period–scope đã công bố trước khi chạy; đo discovery coverage, selection precision sau kiểm tra PDF, download success và policy-skip/lỗi riêng. Đếm URL/blob/phiên bản và byte trước/sau kiểm tra lại; phân biệt HTTP 304 với bỏ qua mạng do có cache local. Đo công sức sửa adapter và metadata review. Nhập tay phải gắn loại nguồn riêng, không cộng như tự crawl.

[Bộ thực nghiệm crawler](../research-crawl-methods/06-thuc-nghiem-va-tai-lap.md) có 8 PDF, 4 doanh nghiệp, 7 trang danh mục và 8 phản hồi 304 ở hai run cuối; 13 test offline pass. Đây là tập phát triển có lỗi đã sửa, không phải coverage 100% toàn thị trường, holdout classifier hoặc độ đúng chín trường. Nội dung thay đổi được thử bằng fixture; chưa quan sát BCTC thật đính chính trong cửa sổ chạy.
