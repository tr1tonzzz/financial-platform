# Lộ trình kiến thức nền gắn với project

Mục tiêu là hiểu phần mình xây đủ để kiểm tra và bảo vệ. Không đặt mục tiêu học toàn bộ ngành tài chính, data science hoặc Python trong 13 tuần.

## 1. Tài chính tối thiểu theo thứ tự

| Học | Bài tập trên project | Điều cần tự giải thích |
|---|---|---|
| Ba BCTC, tài sản/nợ/VCSH | Chỉ đúng 9 dòng trong một PDF | Số tại thời điểm khác dòng phát sinh |
| Doanh thu, lợi nhuận, tiền | Lấy LNST và CFO, viết 5 câu mô tả | Vì sao có lãi nhưng tiền kinh doanh thấp/âm |
| Đơn vị, kỳ, scope | Hai báo cáo khác unit/scope, ghi lý do không ghép | Vì sao một số đúng chữ số vẫn là dữ liệu sai |
| Tỷ số và mẫu số | Tính biên LNST, nợ/tài sản, current ratio bằng tay | Không tính khi thiếu/0/không tương thích |
| Xu hướng và ngành | Hai năm cùng công ty, nhóm ngành nhỏ | Tăng/giảm không tự là tốt/xấu hoặc nhân quả |
| Điều chỉnh/soát xét | So ngày công bố và nhãn assurance | Số mới sửa không có sẵn tại thời điểm cũ |

Ví dụ **giả lập để học**, đơn vị triệu đồng: assets 100, liabilities 40, equity 60, revenue 80, LNST 8, CFO 3, current assets 30, current liabilities 20. Kiểm tra cân đối =0; biên LNST 10%; nợ/tài sản 40%; current ratio 1,5; CFO/LNST 0,375. Đây không phải số của doanh nghiệp thật và không cho kết luận đầu tư. Nếu LNST=0, phải trả không áp dụng cho CFO/LNST theo quy tắc, không trả inf hay 0 giả.

Đọc [SEC beginner guide](https://www.sec.gov/about/reports-publications/beginners-guide-financial-statements) để hiểu cơ chế BCTC; đối chiếu nhãn/đơn vị trong báo cáo Việt Nam thật. Không dùng hướng dẫn Mỹ làm quy định pháp lý hay chuẩn trình bày bắt buộc của Việt Nam.

## 2. Python và dữ liệu

Tuần 1–2: biến/số/chuỗi, list/dict, if/for, hàm, file CSV/JSON, lỗi, pathlib, environment và Git. Nếu còn yếu lập trình chung, bắt đầu ví dụ 10–20 dòng trước khi dùng tutorial Python; tutorial chính thức chủ yếu cho người đã biết lập trình nhưng mới Python.

Tuần 3–4: regex, normalize số, xử lý PDF/OCR, SQL select/insert/join/keys, transaction và hash. Đọc hàm hiện có trong `probe_recent_sources.py`, giải thích input/output và một lỗi, không chạy cả script mà không hiểu.

Tuần 5–6: pandas read/filter/group/merge, missing, UI widget/state, module và unit tests. Tuần 7–10: logs, coverage, batch/resume, versioning, snapshot. Học class/typing khi module cần, không chặn project vì muốn học xong OOP nâng cao.

Nguồn: [Python 3.12 tutorial](https://docs.python.org/3.12/tutorial/), [pandas intro](https://pandas.pydata.org/docs/getting_started/intro_tutorials/index.html), [SQLite SQL](https://www.sqlite.org/lang.html), [Streamlit](https://docs.streamlit.io/get-started/fundamentals). Chốt version cài sau kiểm tra môi trường, không sao chép API của docs mới vào dependency cũ mà chưa thử.

## 3. Phân tích và đánh giá

Học mẫu số/độ phủ, mean/median, phân bố lỗi, đúng trường so với đúng tài liệu, holdout và leakage. Ví dụ parser tìm đúng 9/10 số ở các dòng đã chọn tay không chứng minh tự nhận đúng 90% trên mọi PDF. Mẫu lớn hơn không tự khắc phục sai kỳ/unit. Không học deep learning trước khi viết được baseline và hiểu dữ liệu.

Mỗi tỷ số phải có card ngắn: tên, công thức, ý nghĩa, điều kiện, một ví dụ tay và một trường hợp không áp dụng. Mỗi module có card: input, output, vì sao cần, dependency, lỗi thường gặp, test. Lưu ghi chú tại `learning-log/tuan-NN.md` khi thật sự học, không tạo 13 nhật ký ghi kiến thức đã nắm khi chưa làm.

Các từ kỹ thuật sẽ gặp: pipeline là chuỗi xử lý; metadata là thông tin mô tả tài liệu/số; provenance là nguồn và lịch sử tạo số; candidate là số mới trích chưa duyệt; fact là số được quản lý với kỳ/unit/scope; idempotent là chạy lại không tạo kết quả trùng; baseline là phương án đơn giản để so; holdout là bộ không dùng sửa parser; leakage là dùng nhầm thông tin chưa có tại thời điểm cần đánh giá; API là giao diện để chương trình khác gọi dữ liệu/chức năng. Khi báo cáo, nói nghĩa và ví dụ thay vì chỉ đọc tên tiếng Anh.

## 4. Kiểm tra hiểu sau mỗi tuần

Tự vẽ luồng không nhìn tài liệu; giải thích một hàm do AI hỗ trợ; đổi một input và dự đoán output; tự sửa một lỗi hoặc thêm test; nói 2–3 phút về điều đã học. Nếu không làm được, tuần sau dành buffer ôn chính phần đó thay vì thêm tính năng. Có thể chưa thuộc hết thư viện, nhưng phải hiểu logic, điều kiện và bằng chứng của phần mình trình bày.
