# Đề tài và đặc tả project hiện hành

Phiên bản đề xuất 1.1, 03/10/2026, bổ sung yêu cầu tự phát hiện/cập nhật BCTC từ danh mục chính thức. Tên: **Nền tảng phân tích sức khỏe tài chính doanh nghiệp Việt Nam từ BCTC với dữ liệu có truy vết và kiểm định chất lượng**. Tên ngắn: nền tảng phân tích BCTC có truy vết.

## 1. Bài toán và luồng người dùng

Một người học phân tích muốn xem lợi nhuận có đi cùng tiền, nợ phải trả chiếm bao nhiêu tài sản và số liệu thay đổi thế nào qua năm. Họ cần biết con số đến từ báo cáo nào, đúng đơn vị/kỳ/phạm vi chưa, thay vì chỉ xem biểu đồ đã tính sẵn.

Luồng: chọn doanh nghiệp/kỳ → xem số đã duyệt và mức đầy đủ → đọc chỉ số cùng công thức → xem xu hướng/so sánh phù hợp → mở tài liệu/trang gốc. Người vận hành xử lý hàng đợi ứng viên lỗi/thiếu và sửa có ghi lịch sử. “Sức khỏe” trong đề tài là mô tả nhóm chỉ số; chưa là xếp hạng tín dụng, xác suất phá sản hoặc khuyến nghị đầu tư.

## 2. Đóng góp của một đồ án IT

| Nội dung IT phải xây | Bằng chứng để bảo vệ |
|---|---|
| Thu thập và lưu phiên bản | Adapter, retry hữu hạn, manifest/hash, chạy lại không nhân bản |
| Xử lý dữ liệu bán cấu trúc | PDF text/scan, OCR, parser nhãn/cột, chuẩn hóa kỳ/unit/scope |
| Mô hình dữ liệu và nghiệp vụ | ERD, khóa/constraint, raw–candidate–reviewed, review audit |
| Engine tính và kiểm định | Hàm tính độc lập UI, điều kiện mẫu số, kiểm tra cân đối và missing |
| Ứng dụng dùng dữ liệu thật | Tra cứu, duyệt số, giải thích chỉ số, mở nguồn, export snapshot |
| Đánh giá định lượng | Holdout theo tài liệu/layout, baseline, lỗi trước/sau review, thời gian sửa |

Đây là cơ sở phù hợp đồ án IT theo thiết kế. Nếu chỉ nộp Excel, notebook biểu đồ hoặc dashboard gọi dữ liệu có sẵn mà không chứng minh pipeline/kiểm thử thì chưa đạt mức đóng góp ở bảng. Chưa biết rubric chính thức của trường nên không thể bảo đảm thay quyết định hội đồng; tuần 1 cần đối chiếu yêu cầu môn và tên đề tài với thầy.

## 3. Phạm vi cho một người vừa học vừa làm

Pilot: 3 công ty × 2 năm, đủ thử ít nhất hai layout và có PDF scan/text nếu nguồn phù hợp. Mục tiêu sau gate tuần 4: 10 công ty × 2023–2025 = 30 quan sát doanh nghiệp–năm; không tính file ngôn ngữ khác như quan sát khác. Phạm vi nghiệm thu dự kiến 5–10 công ty và 15–30 báo cáo năm, chốt con số cụ thể sau đo công sức và ghi sổ quyết định. Thu hẹp về 5 công ty không được trình bày như đã đạt mục tiêu 10.

Ưu tiên doanh nghiệp phi tài chính, BCTC năm kiểm toán, hợp nhất và cùng cơ sở kế toán. Báo cáo riêng/cấp doanh nghiệp phải có loại rõ; không trộn vào so sánh hợp nhất. Hai ngành có thể được chọn để minh họa khác biệt nhưng mẫu ngành nhỏ phải ghi là nhóm tham chiếu mô tả, không đại diện thị trường. Quý/bán niên 2026 chỉ thêm 1–2 case nếu còn giờ và parser ổn định.

Chín trường lõi: doanh thu thuần, LNST tổng, CFO, tiền và tương đương tiền, tổng tài sản, nợ phải trả, VCSH tổng, tài sản ngắn hạn, nợ ngắn hạn. Khảo sát trước mới chứng minh sáu trường ở hai tài liệu; ba trường bổ sung cần gate pilot. Trường thiếu giữ missing; nếu không thu được current assets/liabilities thì bỏ tỷ số thanh khoản cho quan sát đó, không thay bằng tổng tài sản/tổng nợ.

## 4. Yêu cầu MVP

| Mã | Chức năng | Điều kiện nghiệm thu |
|---|---|---|
| PF01 | Quản lý công ty, kỳ và nguồn | Coverage có mẫu số và lý do chọn/thiếu |
| PF02 | Tự tìm link BCTC trên danh mục IR và tải/cập nhật; nhập file có nguồn cho fallback | Có ít nhất một adapter tự phát hiện link, không seed từng PDF; giữ catalog/URL/robots, publication evidence, checked_at/retrieved_at/hash; đo tự crawl/nhập riêng, chạy lại không tạo bản trùng |
| PF03 | Trích/chuẩn hóa | Giá trị gốc và chuẩn, kỳ/unit/scope, trang/locator, parser version |
| PF04 | Kiểm định và duyệt | Cờ lỗi, sửa giữ trước/sau/lý do, chưa duyệt không xuất như fact đúng |
| PF05 | Lưu SQLite và snapshot | Chạy lại không trùng, giữ phiên bản và giao dịch cập nhật hợp lệ |
| PF06 | Tính chỉ số | Công thức/operands, điều kiện denominator, missing có lý do |
| PF07 | Dashboard | Chọn công ty/kỳ, xu hướng, nhóm so sánh phù hợp, truy nguồn |
| PF08 | Xuất dữ liệu và báo cáo chất lượng | CSV/JSON với manifest/schema/config, kết quả baseline/holdout |
| PF09 | Demo từ đầu đến cuối | Ít nhất một file mới đi qua quy trình và một lỗi được phát hiện |

FastAPI read-only là nâng cấp tuần 10 nếu lõi xong và rubric cần API; không buộc học React hay hai backend song song. Đăng nhập, nhiều người dùng, giao dịch thật, cổ tức, ML/RAG, realtime và microservices thuộc ngoài MVP.

## 5. Câu hỏi nghiên cứu

RQ1: Kết hợp đọc text, OCR và kiểm định có cải thiện độ đúng/độ phủ so với text-only trên mẫu BCTC đã chốt không? RQ2: Công sức review là bao nhiêu và lỗi hay xảy ra ở bước nào? RQ3: Người đọc có thể tái tính và truy nguồn cho các chỉ số/case mà hệ thống trình bày không? Không đặt câu hỏi dự báo giá hoặc nhân quả tài chính trong project này.

RQ4 bổ sung: Trên danh sách nguồn/kỳ đã freeze, collector tìm đúng và tải được bao nhiêu BCTC đã công bố; khi kiểm tra lại có giữ phiên bản, tránh trùng và giảm byte tải không? [Thực nghiệm crawl](../research-crawl-methods/06-thuc-nghiem-va-tai-lap.md) đã có proof tám PDF/HTTP 304 trên tập phát triển, chưa là benchmark nguồn độc lập hoặc kết quả trích chín trường.

## 6. Gate nghiệm thu

100% giá trị xuất bản có nguồn/locator/period/unit/scope; các target chưa tìm được được tính vào missing. Mục tiêu thăm dò trước review là ≥95% joint correctness trên bộ holdout, báo cáo mẫu số và giới hạn chấm độc lập; đây chưa là kết quả đạt. Có baseline, test nghiệp vụ, lịch sử sửa, hướng dẫn chạy, ba case được đối chiếu và báo cáo giới hạn. Nếu số liệu hoặc cỡ mẫu không đủ, mô tả đúng điều đã làm và chốt giảm scope với thầy, không đổi định nghĩa metric để đạt tỷ lệ.

Đề xuất trình thầy: “Em xây một nền tảng xử lý BCTC Việt Nam, từ thu thập PDF đến dữ liệu có kiểm định và nguồn truy vết. Hệ thống giúp đọc xu hướng lợi nhuận, dòng tiền và cấu trúc tài chính. Em tập trung đánh giá độ đúng, độ phủ, thời gian xử lý và ứng dụng chạy thật. Giai đoạn tốt nghiệp có thể phát triển hỏi đáp số liệu có phép tính kiểm chứng trên nền dữ liệu này.”
