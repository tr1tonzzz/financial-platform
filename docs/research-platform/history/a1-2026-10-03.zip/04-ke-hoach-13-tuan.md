# Kế hoạch vừa học vừa làm trong 13 tuần

Giả định một người, 10–12 giờ/tuần; tổng 130–156 giờ. Tuần tính tương đối, không mặc định còn đủ 13 tuần của học kỳ. Mốc chuẩn 11 giờ/tuần: học 2,5; làm 5; kiểm thử/đối chiếu 1; Word + slide + luyện nói 1,5; dự phòng 1. Tổng 143 giờ, **đã bao gồm báo cáo và học**, không cộng chúng bên ngoài ngân sách. Học theo phần việc tuần, không học hết tài chính/Python rồi mới bắt đầu.

## Mỗi tuần có sản phẩm, kiến thức và điều phải tự nói được

| Tuần | Học để làm | Sản phẩm cuối tuần | Demo và chủ đề báo cáo thầy |
|---|---|---|---|
| 1 | Python biến/list/dict/hàm; ba BCTC; Git | Đọc một PDF; nhập 9 ô có nguồn vào JSON, từ điển nhỏ, scope và source list | Chỉ đúng doanh thu/LNST/CFO; trình so sánh hướng và đề tài IT |
| 2 | HTTP/file/JSON, selector/urljoin, lỗi; kỳ/unit/scope | Collector tự tìm link từ một danh mục IR; tải/hash file thật; một CSV chạy tới bảng chỉ số tính tay | Danh mục → link → PDF, giải thích fallback và vì sao kỳ khác ngày công bố |
| 3 | Regex, PDF text/scan, OCR cơ bản | Pilot 3 công ty × 2 năm; parser tạo candidates, ghi missing; chốt 9 trường có khả thi không | Một trang text và một scan; lỗi nhầm số/cột, không giấu failure |
| 4 | SQL keys/join/transaction; validation | SQLite + schema/ERD, review audit; đo phút xử lý/report và chọn scope 5–10 công ty | Chạy lại không trùng, sửa một số có lịch sử; báo cáo gate scope |
| 5 | pandas, công thức và denominator; Streamlit | UI đầu tiên: một công ty, 2 năm, nguồn và chỉ số | Demo end-to-end tối thiểu; tính tay một chỉ số rồi so code |
| 6 | Modular code, tests; so sánh cùng cơ sở | Validator và engine chỉ số tách UI; bộ test lỗi/unit/missing | Một tài liệu thiếu trường trả lý do, không có điểm giả; chốt baseline và evaluation protocol |
| 7 | Batch/resume, coverage; đọc báo cáo nhanh | Mở rộng tới scope đã chốt; bảng expected/found/reviewed; freeze bộ holdout | Coverage với mẫu số; số giờ thật; không tăng công ty nếu review quá tải |
| 8 | Thống kê lỗi, accuracy và measurement | Chạy B0/B1/B2 trên holdout, ghi trước/sau review và phút sửa | Bảng thí nghiệm, 2–3 loại lỗi; kết quả yếu vẫn báo cáo |
| 9 | Phân tích xu hướng, mô tả, giới hạn ngành | Ba case có fact/operand IDs; biểu đồ và nhóm tham chiếu hợp lệ | Lãi khác tiền, nợ phải trả khác nợ vay; giải thích một biến động từ nguồn |
| 10 | Idempotency/versioning, kỹ thuật triển khai | Hoàn thiện update/resume/export; FastAPI đọc nếu lõi đã xong và môn yêu cầu | Một file mới hoặc phiên bản mới; dữ liệu cũ vẫn truy được |
| 11 | Viết báo cáo kỹ thuật, sơ đồ và tái lập | Report project gần hoàn chỉnh, README chạy, ERD/architecture, chốt scope | Người khác chạy từ hướng dẫn; đối chiếu claim với artifact |
| 12 | Thuyết trình và giải thích code | Slide bảo vệ, demo ổn định, câu hỏi kỹ thuật/tài chính, sửa lỗi quan trọng | Hai lần diễn tập 8–12 phút, mở code và trả lời không đọc AI |
| 13 | Ôn phần yếu; kiểm tra package | Buffer, report/slide cuối và bundle dữ liệu/config/test | Demo trên máy sạch hoặc môi trường mới; nộp giới hạn rõ |

Các hàng là mục tiêu tương lai, không phải tiến độ đã đạt. Mỗi tuần lưu Word 2–4 trang và 5–6 slide, có artifact/test/log thật và phần tuần sau. Số giờ review lớn hơn giả định phải đổi scope trước khi hết buffer.

[Nghiên cứu crawler mới](../research-crawl-methods/07-ke-hoach-tich-hop-va-dong-gop-it.md) được tích hợp vào công việc collector tuần 2–4, batch tuần 7 và update tuần 10, không cộng giờ ngoài bảng. Bắt đầu 1–2 adapter và nguồn có chính sách rõ; case 2026 chỉ để chứng minh cập nhật, không mở rộng mọi quý. Prototype đã chạy trong nghiên cứu không thay việc người thực hiện tự học/viết/giải thích collector.

## Gate và đường thu hẹp

- Cuối tuần 2: một luồng nhập/tải đến số có nguồn phải chạy; chưa chạy thì bỏ tính năng ngoài lõi và tập trung vertical slice.
- Cuối tuần 4: đo thời gian sáu báo cáo pilot, nguồn/lỗi của chín trường; quyết định 5 hay 10 công ty và lưu lý do. Không mặc định phải 30–80 công ty như đề tài cổ tức cũ.
- Cuối tuần 6: nếu UI/validator chưa ổn, không làm cổ tức, quý 2026, FastAPI hoặc AI; giữ một app Python hoàn chỉnh.
- Cuối tuần 8: freeze scope; sửa reliability, benchmark và report; không chạy theo một kiến trúc mới.
- Cuối tuần 11: feature freeze; chỉ sửa lỗi ảnh hưởng đúng số, chạy và trình bày.

Nếu thực tế chỉ còn 8–10 tuần: chọn 5 công ty × 3 năm, một adapter, một kiểu OCR/manual review, Streamlit, không API/AI/quý. Nếu dưới 6–7 giờ/tuần hoặc ít hơn 8 tuần, phải lập lại scope theo hạn nộp, không giữ bảng 13 tuần này như cam kết.

## Nhịp học và báo cáo

Buổi 1: học 45–60 phút đúng khái niệm và viết ví dụ nhỏ. Buổi 2: code task chính, xem đầu vào/ra. Buổi 3: test/đọc ảnh/sửa. Buổi 4: Word, slide và luyện nói. Có ít nhất một việc tự làm không nhờ AI viết thay mỗi tuần. Sau buổi gặp thầy, ghi phản hồi, cập nhật task tuần sau và scope decision nếu cần; không sửa âm thầm chỉ để báo “đúng tiến độ”.

Tuần 1 không dành toàn bộ 11 giờ cho đọc tài liệu: sau 2–3 giờ phải có JSON/CSV đầu tiên. Tuần 2 đã chạy một nhánh nhỏ, tuần 5 có UI. Báo cáo tiến độ hằng tuần là phần của quy trình phát triển chứ không đợi tới cuối mới viết.
