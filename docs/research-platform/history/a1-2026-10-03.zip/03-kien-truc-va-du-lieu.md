# Thiết kế hệ thống và dữ liệu

Thiết kế tương lai, 03/10/2026. Đây không phải mô tả code đã triển khai.

## 1. Stack và phân lớp

Python cho mọi module đầu tiên; `pandas` cho bảng; `sqlite3` cho lưu dữ liệu; `pdfplumber` và OCR cho báo cáo; Streamlit cho UI. Chọn Python 3.12 đang có cho môi trường phát triển, chốt/pin version dependency sau smoke test, không nâng lên version mới nhất chỉ vì docs web dùng version mới. FastAPI/PostgreSQL là mở rộng, chưa yêu cầu cài trong lượt lập kế hoạch này.

```mermaid
flowchart LR
  A[Danh mục IR chính thức] --> B[Phát hiện link và phân loại ứng viên]
  B --> K[Downloader conditional GET và manifest]
  L[File nhập có nguồn] --> K
  K --> C[Raw storage theo hash và phiên bản]
  C --> D[Trích text hoặc render và OCR]
  D --> E[Candidate facts]
  E --> F[Validator và hàng đợi duyệt]
  F --> G[SQLite facts đã duyệt]
  G --> H[Engine chỉ số]
  H --> I[Dashboard và export]
  G --> J[Snapshot và thí nghiệm]
```

Module dữ liệu không phụ thuộc UI. Dự kiến `src/collect`, `src/extract`, `src/normalize`, `src/validate`, `src/store`, `src/analysis`, `src/ui`; đây là cấu trúc đề xuất, chưa tạo các file rỗng rồi coi là hoàn thành module. Bắt đầu một script chạy một file, refactor khi thực sự cần.

## 2. Schema cần hiểu và tự giải thích

| Bảng | Vai trò / trường chính |
|---|---|
| companies | ID, ticker, tên, ngành, scope cohort |
| source_checks | catalog/URL/host policy, checked_at, HTTP status/headers, error và kiểu tự crawl/nhập |
| documents | issuer, period, scope, accounting basis, assurance, URL, hash, version, publication evidence, retrieved_at |
| extraction_runs | document, parser/config version, trạng thái, thời gian/lỗi |
| fact_candidates | metric, raw label/value/unit, normalized value, period, page/bbox, method, cờ lỗi |
| reviewed_facts | candidate, giá trị được duyệt, period/unit/scope, review status |
| reviews | giá trị trước/sau, người sửa, thời điểm, lý do và nguồn |
| derived_metrics | metric/formula version, giá trị, danh sách operand IDs, missing reason |
| snapshots | cutoff snapshot, danh sách document/fact versions, coverage và cấu hình |

Document identity không chỉ là ticker/year; dùng hash/version và khóa nghiệp vụ period/scope/language. Fact uniqueness theo phiên bản tài liệu, metric, kỳ/cột và scope. Foreign key giúp không có fact trỏ tới nguồn không tồn tại. Transaction giúp sửa fact và audit nhất quán. Retrieval timestamp khác publication date; thiếu ngày công bố ghi unknown, không gán ngày cuối năm.

## 3. Data dictionary và công thức

Tiền lưu VND số nguyên hoặc Decimal; tỷ số và làm tròn chỉ ở display. LNST/CFO/doanh thu là dòng trong kỳ; tài sản/tiền/nợ/VCSH là số dư cuối kỳ. Chín metric codes: `revenue_net`, `net_income_total`, `cfo`, `cash_equivalents`, `total_assets`, `total_liabilities`, `total_equity`, `current_assets`, `current_liabilities`.

| Chỉ số | Công thức | Điều kiện |
|---|---|---|
| Biên LNST | LNST tổng / doanh thu thuần | Doanh thu >0, cùng scope/kỳ |
| Nợ phải trả trên tài sản | Nợ phải trả / tài sản | Tài sản >0; không gọi là tỷ lệ nợ vay |
| Thanh khoản hiện hành | TS ngắn hạn / nợ ngắn hạn | Đủ hai trường, nợ ngắn hạn >0 |
| CFO trên LNST | CFO / LNST tổng | LNST >0; âm/0 xử lý trạng thái riêng |
| Tăng trưởng doanh thu | (R_t − R_(t-1)) / R_(t-1) | R_(t-1)>0, đủ hai kỳ tương thích |
| ROA, mở rộng | LNST / tài sản bình quân | Đủ số đầu/cuối kỳ, scope tương thích |

Không tính ROA tài sản bình quân từ một số cuối năm rồi vẫn đặt tên như đủ dữ liệu. Không tổng hợp các tỷ số thành điểm 0–100 khi chưa có protocol. Dashboard tách ba nhóm lợi nhuận, dòng tiền, cấu trúc/khả năng thanh toán và luôn hiển thị mức đủ dữ liệu.

## 4. Kiểm định và vận hành

Kiểm tra âm ngoặc, đơn vị, nhãn/cột, `A=L+E` với sai số theo đơn vị/rounding; kiểm tra mã dòng theo phiên bản, không hard-code chung. So sánh dữ liệu điều chỉnh với bản trước nhưng không tự sửa đè. Source download giữ retry giới hạn và robots/policy theo host; các đường REE/FPT bị loại trong khảo sát trước chưa được coi là có nguồn tự động hợp lệ.

UI duyệt hiển thị ảnh/vị trí gốc và operand/cờ lỗi, giữ sửa có audit. PDF upload phải giới hạn loại/kích thước và không chạy mã chứa trong file. Đường raw theo ID/hash, không dùng tên người dùng làm đường file tùy ý. Log không chứa tài khoản/API key. Test meaningful đặt ở normalize, missing, formulas, store idempotency và end-to-end một file thật; không viết test chỉ xác nhận có biểu đồ.

## 5. Tái sử dụng nghiên cứu đã có

Probe cũ giúp tải/inspect và OCR nhỏ: seed flags chưa là robots engine; trang OCR đang chọn tay; parser regex có một trường miss; giá trị đối chiếu là mẫu phát triển. [Crawler nghiên cứu mới](../../scripts/research/crawl_official_reports.py) đã tự đọc danh mục, phân trang có giới hạn, áp dụng robots rules pilot, conditional GET và history theo hash, với 13 test offline. Parser robots chưa đầy đủ RFC, history JSON chưa có transaction/concurrency; cần đọc hiểu rồi tách module, không đưa thẳng thành production. Raw evidence giữ trong thư mục Git ignore, shared dataset phải có manifest và cách tái dựng/cung cấp phù hợp.

Nguồn kỹ thuật: [Python tutorial](https://docs.python.org/3.12/tutorial/), [pandas tutorials](https://pandas.pydata.org/docs/getting_started/intro_tutorials/index.html), [SQLite SQL](https://www.sqlite.org/lang.html), [Streamlit fundamentals](https://docs.streamlit.io/get-started/fundamentals), [thiết kế crawl từ khảo sát](../research-recent-data/04-thiet-ke-crawl-va-chuan-hoa.md).
