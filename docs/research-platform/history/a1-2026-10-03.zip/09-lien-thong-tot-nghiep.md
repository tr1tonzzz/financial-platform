# Liên thông từ project lên đồ án tốt nghiệp

Không chỉ tăng số công ty hoặc làm giao diện đẹp hơn. Giai đoạn tốt nghiệp cần một câu hỏi kỹ thuật sâu hơn, baseline và đánh giá độc lập. Rubric/thời gian tốt nghiệp chưa được cung cấp; dưới đây là hướng phát triển, không bảo đảm trường chấp nhận liên thông tự động.

## 1. Hướng ưu tiên

Tên dự kiến: **Hệ thống hỏi đáp số liệu tài chính doanh nghiệp Việt Nam có truy vết và phép tính kiểm chứng**. Người dùng hỏi “doanh thu tăng bao nhiêu”, “CFO/LNST năm nào thấp hơn”, “chỉ tiêu này từ đâu”; hệ thống truy facts đúng kỳ/scope và thực hiện phép tính bằng engine, trả nguồn hoặc từ chối khi thiếu.

[FinQA](https://aclanthology.org/2021.emnlp-main.300/) và [TAT-QA](https://aclanthology.org/2021.acl-long.254/) đã nghiên cứu suy luận số/bảng/văn bản trong tài chính. Vì thế không tuyên bố ý tưởng hỏi đáp tài chính là mới toàn cầu. Cơ hội nghiên cứu là tài liệu Việt Nam, kiểm soát period/scope/provenance và thí nghiệm của giải pháp cụ thể.

## 2. Tài sản project được tái sử dụng

Raw documents và metadata, facts được duyệt, schema/canonical metric dictionary, calculator/validator, corpus nguồn, benchmark extraction, UI và test. Giữ module tách UI để có thể cung cấp tool/API; không phải viết lại collector vì đổi frontend.

## 3. Đầu ra mới của tốt nghiệp

Một bộ câu hỏi tiếng Việt có answer, operand IDs, calculation program, source locator và trường hợp unanswerable. Chốt rubric gold và chấm độc lập nếu có người hỗ trợ; ngưỡng cỡ mẫu cần lập sau pilot, không dùng vài câu demo làm evaluation. Split theo tài liệu/công ty/kỳ tùy câu hỏi nghiên cứu, tránh các bản dịch cùng báo cáo nằm ở hai tập.

So baseline lookup/template, retrieval + LLM và retrieval + calculator/schema với cùng dữ liệu/câu hỏi. Đo numerical correctness, period/scope correctness, citation support, retrieval recall, abstention, latency/cost. Chỉ dùng mô hình/dịch vụ có điều kiện tài khoản/chi phí được kiểm tra tại thời điểm triển khai; chưa chọn model hay mua API trong lượt này. Structured data đã duyệt và raw PDF là hai điều kiện thử riêng, không bỏ qua lỗi extraction bằng giả định hoàn hảo.

## 4. Các giai đoạn thay vì cam kết thời gian chưa biết

G1: củng cố dataset và protocol. G2: tạo gold và baseline. G3: triển khai retrieval/tools và thí nghiệm ablation. G4: đánh giá ngoài mẫu, phân tích lỗi và ứng dụng/report. Lịch tuần cụ thể lập khi biết hạn tốt nghiệp và nền tảng đạt sau project.

Nếu sau project bạn thích kỹ thuật dữ liệu hơn NLP, chọn **phát hiện sai lệch, điều chỉnh và bất thường trong chuỗi BCTC có truy vết** làm hướng thay thế. Nhãn và số phiên bản cần kiểm tra, không suy gian lận từ bất thường. Nếu thích tài chính cổ tức, A2 vẫn là module/câu hỏi nghiên cứu khác với gate nhãn đã nêu. Không bắt buộc triển khai cả ba nhánh tốt nghiệp.
