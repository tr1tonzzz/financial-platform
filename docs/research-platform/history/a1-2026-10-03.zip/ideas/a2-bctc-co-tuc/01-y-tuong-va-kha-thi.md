# Quan hệ BCTC và cổ tức

Khảo sát và đề xuất ngày 03/10/2026. Trạng thái: thiết kế/đánh giá khả thi, không phải chức năng ứng dụng đã hoàn thành.

## Bài toán và người dùng

Người theo dõi cổ tức cần biết mức chi trả được lợi nhuận và dòng tiền hỗ trợ thế nào. Ghép BCTC với thông báo quyền thành chuỗi sự kiện có mốc công bố và năm lợi nhuận.

## Dữ liệu và bằng chứng khả thi

BCTC cộng thông báo cổ tức tiền mặt từ VSDC/IR. Đã tải bốn thông báo cho hai công ty, không phải lịch sử đủ toàn cửa sổ. Cần kiểm tra đề xuất, thông báo chính thức, điều chỉnh và xác nhận thực hiện.

## MVP nếu chọn hướng này

Một module trên nền dữ liệu A1: timeline cổ tức, DPS theo thành phần năm lợi nhuận và vài case lợi nhuận–tiền. Nếu chọn làm đề tài chính, phải dành thêm công sức độ phủ sự kiện và thiết kế nhãn.

## Đóng góp IT và cách đánh giá

Đúng ticker, tiền/cổ phiếu, DPS, năm lợi nhuận, ngày; tỷ lệ sự kiện có nguồn và cửa sổ đủ. Đánh giá dự báo chỉ sau gate nhãn và chia thời gian.

## Điểm khó cần xử lý

Nhãn năm 2026 chưa trưởng thành cho cửa sổ 12 tháng; không tìm thấy không nghĩa không trả. Nhiều ngày thanh toán chỉ là lịch. Hướng cũ mạnh về ngữ nghĩa nhưng nặng đối với người mới.

## Liên thông lên đồ án tốt nghiệp

Có thể là nghiên cứu duy trì/cắt giảm cổ tức trên dữ liệu trưởng thành; cần baseline và nhãn công bố hoặc thực trả được chọn rõ.

## Tài liệu đi kèm

[Kiến thức tài chính](02-kien-thuc-tai-chinh.md); [kỹ thuật IT](03-ky-thuat-it.md). Nguồn: [Khảo sát VSDC và nhãn](../../../research-recent-data/03-ky-tai-chinh-co-tuc-va-nhan.md); [thiết kế nhánh cổ tức](../../../research-design.md).
