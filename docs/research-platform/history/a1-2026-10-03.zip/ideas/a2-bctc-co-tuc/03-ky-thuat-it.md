# Kỹ thuật IT cho quan hệ bctc và cổ tức

Adapter HTML theo trường mã chứng khoán, tách phần thông báo khỏi tin liên quan, lưu notice ID và bảng event_components; phát hiện trùng route, điều chỉnh và hủy. Dựng coverage ledger theo công ty–cửa sổ; trạng thái unknown/censored. Point-in-time join chống dùng dữ liệu tương lai. Kiểm thử một event nhiều năm và một sự kiện sửa lịch. Pipeline A1 tái sử dụng, nhưng dataset sự kiện và bộ chấm phải xây riêng.

Đầu ra cần giữ: source code module, dữ liệu đầu vào có nguồn, cấu hình, test phù hợp, log chạy và hạn chế. Đọc được dữ liệu hoặc gọi được thư viện không thay thế đánh giá đúng/sai trên bộ mẫu.

Nguồn và hồ sơ: [Khảo sát VSDC và nhãn](../../../research-recent-data/03-ky-tai-chinh-co-tuc-va-nhan.md); [thiết kế nhánh cổ tức](../../../research-design.md).
