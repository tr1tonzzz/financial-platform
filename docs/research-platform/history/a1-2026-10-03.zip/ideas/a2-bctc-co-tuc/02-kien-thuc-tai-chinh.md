# Kiến thức tài chính cho quan hệ bctc và cổ tức

DPS là đồng/cổ phiếu; tỷ lệ mệnh giá khác yield theo giá thị trường. Ngày công bố, chốt quyền, lịch trả và thực trả khác nhau. Năm lợi nhuận khác năm trả tiền. Một thông báo VNM đã đọc gộp 350 đồng thuộc 2024 với 2.500 đồng thuộc 2025. LNST tổng hợp nhất không tự là tiền có thể chia ở công ty mẹ. Bài tập: tách một thông báo thành hai thành phần, giải thích vì sao chưa được gán nhãn tiền đã trả.

Học bằng một ví dụ tính tay trước, sau đó viết lại bằng Python và ghi điều kiện áp dụng. Không xem kết quả số là kết luận đầu tư hoặc xác suất rủi ro nếu chưa có thiết kế kiểm định.

Nguồn học/nghiên cứu: [Khảo sát VSDC và nhãn](../../../research-recent-data/03-ky-tai-chinh-co-tuc-va-nhan.md); [thiết kế nhánh cổ tức](../../../research-design.md).
