# Chuẩn bị bảo vệ từ lúc làm project

Mục tiêu là trình bày và kiểm chứng hệ thống mình làm. Chưa cần thành chuyên gia tài chính để bắt đầu, nhưng phải hiểu dữ liệu và logic của các chức năng mình bảo vệ.

## 1. Sáu năng lực phải có bằng chứng

| Năng lực | Tự kiểm tra |
|---|---|
| Hiểu bài toán | Nói trong một phút người dùng cần gì và hệ thống giải quyết đến đâu |
| Hiểu dữ liệu | Mở PDF, chỉ dòng/kỳ/unit/scope và lý do chọn nguồn |
| Hiểu thiết kế | Vẽ schema/luồng, giải thích raw khác candidate/reviewed và vì sao lưu hash |
| Hiểu code | Mở một hàm quan trọng, giải thích từng bước và đổi một điều kiện |
| Hiểu đánh giá | Nêu baseline/mẫu số, missing, holdout và giới hạn tự chấm |
| Hiểu kết quả | Tính tay một tỷ số, truy operands, giải thích giới hạn kinh tế |

Mỗi tuần ghi một câu chuyện lỗi thật: triệu đồng bị đọc thành VND, nhầm cột, filename thay đổi, file nhập trùng hoặc mẫu số 0. Câu chuyện có trước/sau/test sẽ giúp bảo vệ thuyết phục hơn liệt kê thư viện.

## 2. Câu hỏi cần luyện

1. Vì sao đây là IT? Trả lời bằng pipeline, schema, algorithms, tests và benchmark cụ thể, không chỉ “em dùng Python”.
2. Vì sao chọn BCTC hơn giá/cổ tức? Dữ liệu chính thức đã thử và scope vừa sức; trình nghiên cứu bảy hướng.
3. Vì sao lợi nhuận khác tiền? Giải thích ghi nhận doanh thu/chi phí và tiền thu/chi, dùng case có nguồn.
4. Vì sao OCR đúng số nhưng hệ thống vẫn sai? Có thể sai unit, kỳ, scope hoặc cột.
5. Vì sao không dùng một điểm sức khỏe tổng? Chưa kiểm định trọng số/nhãn; ba nhóm chỉ số có giới hạn.
6. Vì sao chọn SQLite/Streamlit? Một người/máy và ngân sách học; giải thích ranh giới module để nâng cấp sau.
7. Độ chính xác tính thế nào? Target kỳ vọng, joint correctness và trước/sau review; nêu cỡ mẫu.
8. Giải pháp mới ở đâu? Đóng góp triển khai/kiểm định với dữ liệu Việt Nam, không tuyên bố OCR/công thức mới.
9. Dữ liệu không có thì sao? Missing/reason, không 0; giảm scope trước deadline có ghi quyết định.
10. AI viết code thì bạn làm gì? Chỉ logic đã đọc, test do mình kiểm tra và thay đổi mình tự thực hiện.

## 3. Dùng AI để học mà vẫn hiểu

Yêu cầu AI giải thích một module nhỏ và cho test, sau đó đọc input/output và nguồn. Tự viết lại một hàm từ mô tả hoặc sửa một test chưa có đáp án. Lưu decisions: lựa chọn, lý do, đối án, tài liệu và hạn chế. Không học thuộc bản giải thích dài nhưng chưa chạy code. Không đưa số hoặc kết quả do AI suy đoán vào Word/slide như đã đo.

Definition of done cá nhân: chạy được, test được, truy nguồn được và tự nói được. Nếu chưa giải thích được thì task kỹ thuật có thể chạy nhưng phần học vẫn chưa xong; ghi đúng trạng thái.

## 4. Demo bảo vệ gợi ý

8–12 phút: bài toán và scope; kiến trúc/schema; một file vào hệ thống; một lỗi được flag/sửa; một chỉ số truy nguồn và tính tay; bảng B0/B1/B2; giới hạn và hướng tốt nghiệp. Có dataset snapshot/demo fallback nếu mạng nguồn lỗi. Không trình ảnh chụp của demo khác hoặc số giả lập như dữ liệu thật. Tuần 12 tập hai lượt, một lượt có người hỏi và yêu cầu thay input.
