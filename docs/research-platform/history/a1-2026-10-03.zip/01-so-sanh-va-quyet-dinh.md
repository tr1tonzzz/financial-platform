# So sánh hướng của nền tảng tài chính

Ngày 03/10/2026. Việc rà soát trước đã thu hẹp nền tảng thành BCTC–cổ tức quá sớm. Lần này coi quan hệ BCTC–cổ tức là một trong bảy hướng, không lấy nó làm ràng buộc bắt buộc.

## Tiêu chí theo hoàn cảnh của người thực hiện

Chấm 1–5, cao là thuận lợi: dữ liệu 30%, độ vừa sức khi học 25%, đóng góp IT 20%, khả năng liên thông tốt nghiệp 15%, tận dụng công việc hiện tại 10%. Đây là phán đoán thiết kế của người nghiên cứu, không phải kết quả khảo sát người dùng, thí nghiệm hay ý kiến phê duyệt của thầy. Một tiêu chí thay đổi có thể đổi thứ hạng.

| Hướng | Dữ liệu | Vừa sức | IT | Tốt nghiệp | Tái sử dụng | Điểm có trọng số |
|---|---:|---:|---:|---:|---:|---:|
| [Phân tích sức khỏe tài chính doanh nghiệp](ideas/a1-suc-khoe-doanh-nghiep/01-y-tuong-va-kha-thi.md) | 4 | 4 | 5 | 5 | 5 | 4.45 |
| [Quan hệ BCTC và cổ tức](ideas/a2-bctc-co-tuc/01-y-tuong-va-kha-thi.md) | 4 | 3 | 4 | 4 | 5 | 3.85 |
| [Phân tích rủi ro và hiệu quả danh mục](ideas/a3-rui-ro-danh-muc/01-y-tuong-va-kha-thi.md) | 2 | 2 | 4 | 5 | 2 | 2.85 |
| [Quản lý thu chi và ngân sách cá nhân](ideas/a4-tai-chinh-ca-nhan/01-y-tuong-va-kha-thi.md) | 5 | 4 | 4 | 3 | 1 | 3.85 |
| [Theo dõi công nợ và mô phỏng dòng tiền doanh nghiệp nhỏ](ideas/a5-dong-tien-doanh-nghiep-nho/01-y-tuong-va-kha-thi.md) | 2 | 3 | 4 | 4 | 1 | 2.85 |
| [Hỏi đáp tài liệu tài chính có bằng chứng và phép tính](ideas/a6-hoi-dap-tai-lieu/01-y-tuong-va-kha-thi.md) | 4 | 2 | 5 | 5 | 4 | 3.85 |
| [Nền tảng dữ liệu và so sánh chỉ tiêu vĩ mô](ideas/a7-du-lieu-vi-mo/01-y-tuong-va-kha-thi.md) | 5 | 3 | 4 | 4 | 2 | 3.85 |

## Quyết định đề xuất

Chọn A1 làm project: **Nền tảng phân tích sức khỏe tài chính doanh nghiệp Việt Nam từ BCTC với dữ liệu có truy vết và kiểm định chất lượng**. Cổ tức trở thành module tùy chọn, không là điều kiện hoàn thành lõi. Tên đăng ký chính thức còn cần đối chiếu rubric và trao đổi với thầy; không có bằng chứng thầy đã đồng ý.

A4 dễ lấy dữ liệu kiểm thử và làm phần mềm, nhưng chuyển mạnh khỏi dữ liệu/crawler đã có; nếu thích sản phẩm phục vụ cá nhân hơn, đây là lựa chọn thay thế có thực chất. A7 có đường API đã thử thật và ít OCR, nhưng cần câu hỏi sử dụng rõ và dataset revision để vượt dashboard. A3 có tiềm năng định lượng nhưng nguồn giá và thống kê chưa kiểm chứng. A5 cần dữ liệu nội bộ chưa có. A6 phù hợp giai đoạn tốt nghiệp hơn vì cần nền dữ liệu, đánh giá đáp án và kiến thức NLP/LLM. A2 cần thêm dữ liệu sự kiện và thời gian trưởng thành nhãn.

Nếu bỏ trọng số tái sử dụng và ưu tiên đơn thuần khả năng làm ứng dụng dễ tiếp cận, khoảng cách giữa A1 và A4 thu hẹp. Không diễn giải điểm số là bằng chứng A1 tốt hơn trong mọi bối cảnh.

## Vấn đề đáng nghiên cứu của A1

Làm thế nào trích số đúng kỳ/scope/unit từ BCTC Việt Nam khác layout và scan, giữ bằng chứng, giảm thời gian đối chiếu và phục vụ phân tích có thể kiểm chứng? Đóng góp nằm ở thiết kế và đo lường pipeline, không ở tuyên bố một tỷ số tài chính mới hoặc phát minh OCR.

## Bằng chứng hiện có và phần chưa kiểm chứng

1. Đã tải 15 PDF/5 công ty và bốn HTML cổ tức trong [khảo sát gần hiện tại](../research-recent-data/README.md); VHC gồm hai ngôn ngữ. 12 PDF không có lớp chữ hữu ích theo probe, OCR 10 trang cho bộ tìm dòng 11/12 giá trị khớp ảnh trên mẫu phát triển.
2. Đã đọc tài liệu chính thức của Vnstock, CFPB, Odoo, FinQA/TAT-QA và World Bank. Chưa chạy tải giá, chưa có dữ liệu cá nhân/SME, chưa dựng RAG.
3. World Bank GDP Việt Nam 2020–2025: một request local HTTP 200/sáu giá trị. Không suy ra có đủ dữ liệu vĩ mô quý hiện tại.
4. `src` chưa có file ứng dụng được phát hiện trong lần đọc này. Script nghiên cứu và bộ tài liệu không đồng nghĩa đã có sản phẩm. Kế hoạch tính từ việc dựng một luồng nhỏ chạy thật.
