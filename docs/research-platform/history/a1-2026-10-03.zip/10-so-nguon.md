# Sổ nguồn nghiên cứu và học

Đọc/kiểm tra ngày 03/10/2026. Chỉ nguồn chính thức hoặc bài nghiên cứu gốc được dùng làm căn cứ kỹ thuật. “Đã đọc” khác “đã chạy”; đề xuất scope là suy luận thiết kế, không phải kết quả của tài liệu nguồn.

| Nguồn | Dùng cho | Trạng thái và giới hạn |
|---|---|---|
| [Khảo sát gần hiện tại](../research-recent-data/README.md) | A1/A2, đường IR/HNX/VSDC, PDF/OCR | File local và hash đã kiểm tra; mẫu nhỏ, không đủ độ phủ thị trường |
| [Tự phát hiện/crawl BCTC](../research-crawl-methods/README.md) | A1, dữ liệu mới và cập nhật có phiên bản | Đã chạy 4 IR/8 PDF và 304; sources/classifier là development, chưa benchmark chín trường; robots host file Hòa Phát chưa xác định |
| [HTTP conditional requests](https://www.rfc-editor.org/rfc/rfc9110.html#name-conditional-requests), [robots RFC 9309](https://www.rfc-editor.org/rfc/rfc9309.html) | Conditional GET, source policy | Đã đọc; GET/304 đã thử thật, parser robots pilot chưa đầy đủ RFC |
| [Scrapy Files Pipeline](https://docs.scrapy.org/en/latest/topics/media-pipeline.html), [AutoThrottle](https://docs.scrapy.org/en/latest/topics/autothrottle.html), [Playwright downloads](https://playwright.dev/python/docs/downloads) | Các phương án mở rộng crawler | Đã nghiên cứu tài liệu; chưa chạy Scrapy/Playwright trong thử nghiệm này |
| [SEC beginner guide](https://www.sec.gov/about/reports-publications/beginners-guide-financial-statements) | Nền BCTC và ratios | Đã đọc; tài liệu học cơ chế, không thay chuẩn/pháp luật Việt Nam |
| [Vnstock repository](https://github.com/thinh-vu/vnstock) | A3, nguồn giá qua thư viện | Đã đọc README; kết nối nguồn thứ ba, quyền phần mềm khác quyền dữ liệu; chưa chạy tải giá |
| [CFPB spending tracker](https://www.consumerfinance.gov/archive/blog/track-your-spending-with-this-easy-tool/) | A4 nhu cầu thu chi | Đã đọc; không có dataset người dùng của project |
| [Odoo reporting](https://www.odoo.com/documentation/19.0/applications/finance/accounting/reporting.html) | A5 cash flow/short-term cash forecast | Kết quả search đọc được, open trực tiếp có lúc internal error; chưa có dữ liệu SME |
| [FinQA EMNLP 2021](https://aclanthology.org/2021.emnlp-main.300/) | A6 numerical reasoning và chương trình tính | Đã đọc abstract/trang gốc; không chạy benchmark hoặc tải dataset |
| [TAT-QA ACL 2021](https://aclanthology.org/2021.acl-long.254/) | A6 hybrid tables/text | Đã đọc; số liệu nghiên cứu của họ không là số đo hệ thống này |
| [World Bank API](https://datahelpdesk.worldbank.org/knowledgebase/articles/889392-about-the-indicators-api-documentation) | A7 nguồn vĩ mô có metadata | Đã đọc; request GDP local có bằng chứng [JSON](worldbank-probe.json); chưa kiểm tra vintage |
| [Python 3.12 tutorial](https://docs.python.org/3.12/tutorial/) | Tuần 1–4 | Tài liệu học; tutorial giả định biết lập trình căn bản, không phải toàn bộ chương trình học |
| [pandas intro](https://pandas.pydata.org/docs/getting_started/intro_tutorials/index.html) | Tuần 5–9, tabular operations | Đã mở; version docs có thể khác runtime, pin/test trước khi dùng |
| [SQLite SQL](https://www.sqlite.org/lang.html) | Schema/query/constraints | Đã mở; chưa dựng DB project |
| [Streamlit fundamentals](https://docs.streamlit.io/get-started/fundamentals) | UI một stack Python | Đã mở; chưa dựng app project |

Raw World Bank probe: `data-sets/research-evidence/2026-10-03-platform-options/`, ignored bởi Git. Metadata được lưu trong bộ tài liệu; HTTP 200/sáu dòng GDP không chứng minh mọi chỉ tiêu 2025/2026 đều sẵn có. Dữ liệu công bố mới có thể revised, cần snapshot để tái lập.

## Những điều chưa có căn cứ

Chưa có rubric môn/tốt nghiệp hoặc xác nhận tên đề tài từ thầy; chưa biết hạn thực còn bao lâu; chưa có khảo sát người dùng độc lập; chưa có dataset cá nhân/SME; chưa benchmark parser chín trường, RAG hoặc chiến lược đầu tư. Không đặt các nội dung này thành sự thật trong Word/slide. Nghiên cứu hoàn thành ở mức so sánh và thiết kế; triển khai và học vẫn là công việc kế hoạch.
