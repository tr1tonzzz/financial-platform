# Bộ trao đổi đề xuất với giảng viên

[Báo cáo Word](bao-cao-de-xuat.docx) và [slide đề xuất](de-xuat-project.pptx) trình nghiên cứu hướng, phạm vi IT, bằng chứng nguồn và kế hoạch học/làm. Đây là bộ cho buổi trao đổi định hướng, không phải tiến độ triển khai của 13 tuần đã hoàn thành.

Mỗi tuần sau dùng [quy trình báo cáo](../07-bao-cao-hang-tuan.md) và [mẫu Markdown](../mau-bao-cao-tuan.md), thay nội dung bằng artifact/số đo/kiến thức đã học thực tế. Không gửi tự động hoặc giả lập phản hồi của thầy.
